from typing import Any
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.conf import settings
User = settings.AUTH_USER_MODEL
import django
from .enums import *
from utils.models import TimeStampModel
# Create your models here.

class CustomUserManager(BaseUserManager):
    def _create_user(self, mobile, password=None, **extra_fields):
        if not mobile:
            raise ValueError('The Phone field must be set')
        user = self.model(mobile=mobile, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user
    def create_user(self,mobile,**extra_fields):
        extra_fields.setdefault('is_staff',False)
        extra_fields.setdefault('is_superuser',False)
        extra_fields.setdefault('is_active',True)
        return self._create_user(mobile,**extra_fields)
    
    def create_admin(self,mobile,password,**extra_fields):
        extra_fields.setdefault('is_staff',True)
        extra_fields.setdefault('is_superuser',False)
        extra_fields.setdefault('is_active',True)
        return self._create_user(mobile,password,**extra_fields)
    
    def create_superuser(self, mobile, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active',True)
        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')
        return self._create_user(mobile, password, **extra_fields)
   

class School(models.Model):
    name=models.CharField(max_length=100,blank=True,null=True)
    is_active=models.BooleanField(default=False)

class Grade(models.Model):
    name=models.CharField(max_length=100,blank=True,null=True)

class CustomUser(AbstractBaseUser, PermissionsMixin):
    user_type=models.CharField(max_length=100,choices=UserType.choices())
    username=models.CharField(max_length=100)
    first_name=models.CharField(max_length=100,blank=True,null=True)
    last_name=models.CharField(max_length=100,blank=True,null=True)
    email=models.EmailField(blank=True,null=True)
    dob=models.DateField(blank=True,null=True)
    contact_number=models.CharField(max_length=100)
    poc_name=models.CharField(max_length=100,blank=True,null=True)
    poc_mobile=models.CharField(max_length=100,blank=True,null=True)
    poc_email=models.EmailField()
    name=models.CharField(max_length=100,blank=True,null=True)
    school=models.ForeignKey(School,on_delete=models.CASCADE,blank=True,null=True)
    grade=models.ForeignKey(Grade,on_delete=models.CASCADE,blank=True,null=True)
    state=models.CharField(max_length=100,blank=True,null=True)
    city=models.CharField(max_length=100,blank=True,null=True)
    parent_mobile=models.IntegerField(blank=True,null=True)
    parent_email=models.EmailField(blank=True,null=True)
    address=models.CharField(max_length=200,blank=True,null=True)
    pin_Code=models.IntegerField(blank=True,null=True)
    workspace=models.CharField(max_length=200,blank=True,null=True)
    position=models.CharField(max_length=200,blank=True,null=True)
    qulification=models.CharField(max_length=100,blank=True,null=True)
    parent_mobile_verified=models.BooleanField(default=False)
    mobile_verified=models.BooleanField(default=False)
    bio=models.TextField()
    image=models.ImageField(upload_to='image',blank=True,null=True)
    mobile = models.CharField(max_length=15, unique=True)
    is_active = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    date_joined=models.DateTimeField(default=django.utils.timezone.now)
    is_private=models.BooleanField(default=False)
    objects = CustomUserManager()

    USERNAME_FIELD = 'mobile'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.mobile
    


class PhoneModel(models.Model):
    mobile=models.CharField(max_length=20)
    otp=models.CharField(max_length=20)


class Block(TimeStampModel):
    blocked_user=models.ForeignKey(CustomUser,on_delete=models.CASCADE,related_name='blocked_user')

class FollowRequest(TimeStampModel):
    Category_Choices=(
        ('pending','pending'),
        ('accepted','accepted'),
        ('rejected','rejected')
    )
    receiver=models.ForeignKey(CustomUser,on_delete=models.CASCADE,related_name='follow_receiver')
    status=models.CharField(max_length=100,choices=Category_Choices)
    