from django.contrib import admin
from django.urls import path,include
from rest_framework_simplejwt import views as jwt_views
from app import views
from .views import *
from rest_framework.routers import DefaultRouter
router=DefaultRouter()
router.register('block',views.BlockAPIView,basename='block')
router.register('follow',views.FollowRequestAPIView,basename='follow')

urlpatterns = [
    path('api/token/', jwt_views.TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
    path('hello/', HelloView.as_view(), name='hello'),
    path('register/',RegisterAPIView.as_view(),name='register'),
    path('otp/',GenerateOtpAPIView.as_view(),name='otp'),

] +router.urls


