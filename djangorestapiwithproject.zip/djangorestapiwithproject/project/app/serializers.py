from rest_framework import serializers
import pyotp
from django.core.exceptions import ValidationError
from .models import *
from .enums import *
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from .models import *
from django.contrib.auth import get_user_model
User = get_user_model()
from django.core.exceptions import ValidationError
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

# class LoginSerializer(TokenObtainPairSerializer):
#     @classmethod
#     def get_token(cls,user):
#         token=super().get_token(user)
#         token['user_type']=user.user_type
class LoginSerializer(serializers.Serializer):
    phone = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        mobile = data.get('mobile')
        password = data.get('password')

        user = authenticate(mobile=mobile, password=password)

        if user:
            data['user'] = user
        else:
            raise serializers.ValidationError("Inactive User.")

        return data

    def create(self, validated_data):
        user = validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return user, token.key
    
class RegisterSerializer(serializers.Serializer):
    first_name=serializers.CharField(max_length=100)
    last_name=serializers.CharField(max_length=100)
    mobile=serializers.CharField(max_length=100)
    user_type=serializers.ChoiceField(choices=UserType.choices())
    otp=serializers.IntegerField(write_only=True)
    password=serializers.CharField(max_length=100,write_only=True)

    def is_valid_otp(self,otp,mobile):
        totp=pyotp.TOTP(settings.OTP_SECRET,interval=300,digits=4)
        if totp.verify(otp):
            return PhoneModel.objects.filter(mobile=mobile,otp=otp).exists()
        return False
    
    def validate(self,attrs):
        mobile=attrs.get('mobile')
        otp=attrs.pop('otp')
        user=CustomUser.objects.filter(mobile=mobile).exists()
        if user:
            raise ValidationError('user already exists')
        if not self.is_valid_otp(otp,mobile):
            raise ValidationError('Invalid OTP')
        return super().validate(attrs)
    
    def create(self,validated_data):
        user=CustomUser.objects.create_user(**validated_data)
        PhoneModel.objects.filter(mobile=user.mobile).delete()
        return user
    

class PhoneModelSerializer(serializers.ModelSerializer):
    class Meta:
        model=PhoneModel
        fields=['mobile']
    def create(self,validated_data):
        totp=pyotp.TOTP(settings.OTP_SECRET,interval=300,digits=4)
        otp=totp.now()
        instance, _=self.Meta.model.objects.get_or_create(**validated_data)
        instance.otp=otp
        instance.save()
        return instance
    
class CreateSerializer(serializers.ModelSerializer):
    is_following=serializers.SerializerMethodField()
    def get_is_following(self,data_obj):
        return FollowRequest.objects.filter(created_by=self.context['request'].user,status='accepted').exists()
    
    class Meta:
        model=CustomUser
        fields=['id','user_type','first_name','email','mobile','image','is_following']

class BlockSerializer(serializers.ModelSerializer):
    created_by=CreateSerializer(read_only=True)
    updated_by=CreateSerializer(read_only=True)
    class Meta:
        model=Block
        fields=('blocked_user','created_by','updated_by','created_at','updated_at')
        read_only_fields=('created_by','updated_by','created_at','updated_at')



class FollowSerializer(serializers.ModelSerializer):
    created_by=CreateSerializer(read_only=True)

    class Meta:
        model=FollowRequest
        fields=('receiver','status','created_by')
        read_only_fields=('status','created_by')
    def validate(self, attrs):
        # created_by = attrs.get('created_by')
        created_by=self.context['request'].user
        receiver = attrs.get('receiver')
        if created_by == receiver:
            raise serializers.ValidationError("user can not follow self")
        
        data = FollowRequest.objects.filter(created_by=created_by, receiver=receiver)
        if data:
            raise serializers.ValidationError('user already exists')
        
        return super().validate(attrs)
        
    def create(self,validated_data):
        is_private_user=validated_data['receiver'].is_private
        validated_data['status']='pending' if is_private_user else 'accepted'
        data=FollowRequest.objects.create(**validated_data)
        return data
    
class AllProfileSerializer(serializers.ModelSerializer):
    followers=serializers.SerializerMethodField()
    following=serializers.SerializerMethodField()
    is_following=serializers.SerializerMethodField()
    def get_is_following(self,data_obj):
        return FollowRequest.objects.filter(created_by=self.context['request'].user,status='accepted').exists()
    def get_followers(self,data_obj):
        return FollowRequest.objects.filter(receiver=self.context['request'].user,status='accepted')
    def get_following(self,data_obj):
        return FollowRequest.objects.filter(created_by=self.context['request'].user,status='accepted').count()
    class Meta:
        model=CustomUser
        fields=['id','user_type','username','is_following','email','dob','mobile','name','image','followers','following']



class GradeViewSerializer(serializers.ModelSerializer):
    class Meta:
        model=Grade
        fields=('name',)

class GradeSerializer(serializers.ModelSerializer):
    class Meta:
        model=Grade
        fields='__all__'

class SchoolSerializer(serializers.ModelSerializer):
    class Meta:
        model=School
        fields=('name',)

class ProfileSerializer(serializers.ModelSerializer):
    def validate(self,attrs):
        email=attrs.get('email')
        username=attrs.get('username')
        if email and CustomUser.objects.filter(email=email).exists():
            return serializers.ValidationError('Email already Exist')
        if username and CustomUser.objects.filter(username=username).exists():
            return serializers.ValidationError('Username already Exist')
        return super().validate(attrs)
    
    class Meta:
        model=CustomUser


class StudentSerializer(serializers.ModelSerializer):
    grade=GradeViewSerializer(read_only=True)
    school=SchoolSerializer(read_only=True)
    class Meta:
        model=CustomUser
        fields=('id','user_type','username','is_private','dob','name','mobile','image','school','state','city','address','pin_code','grade','parent_mobile','parent_email')
        read_only_fields=('user_type','mobile')
    def validate_school(self,data):
        school_obj,_=School.objects.get_or_create(name=data)
        return school_obj
    
    