from django.shortcuts import render,get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import generics
from .serializers import *
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import  viewsets
from rest_framework.parsers import FormParser,MultiPartParser

# Create your views here.
class HelloView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        content = {'message': 'Hello, World!'}
        return Response(content)
    

class MyProfileAPIView(generics.GenericAPIView):
    serializer_class=AllProfileSerializer
    def get(self,request):
        serializer=self.serializer_class(request.user,context={'request':request})
        return Response({'data':serializer.data})
    

class ProfileByIdAPIView(generics.RetrieveAPIView):
    serializer_class=AllProfileSerializer
    def get(self,request,user_id):
        instance=get_object_or_404(CustomUser,pk=user_id)
        serializer=self.get_serializer(instance,context={'request':request})
        return Response(serializer.data)
    

class RegisterAPIView(generics.CreateAPIView):
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        user = serializer.instance
        refresh = RefreshToken.for_user(user)
        data = {
            **serializer.data,
            'id': user.id,
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }

        headers = self.get_success_headers(serializer.data)
        return Response(data, status=status.HTTP_201_CREATED, headers=headers)


class GenerateOtpAPIView(APIView):
    serializers_class=PhoneModelSerializer
    def post(self,request):
        serializer=self.serializers_class(data=request.data)
        if serializer.is_valid(raise_exception=True):
            instance=serializer.save()
            content={'mobile':instance.mobile,'otp':instance.otp}
            return Response(content,status=status.HTTP_201_CREATED)
        return Response({'message':'invalid number'},status=status.HTTP_400_BAD_REQUEST)
    

class BlockAPIView(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serialzer_class=BlockSerializer
    http_method_names = ['get', 'post']  # Specify the allowed HTTP methods here
    def get_queryset(self):
        return Block.objects.filter(created_by=self.request.user)
    def perform_create(self,serializer):
        serializer.save(created_by=self.request.user,updated_by=self.request.user)

class FollowRequestAPIView(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class=FollowSerializer
    queryset = FollowRequest.objects.all()
    http_method_names = ['get', 'post']  # Specify the allowed HTTP methods here
   
    def perform_create(self,serializer):
        serializer.save(created_by=self.request.user,updated_by=self.request.user)

class FollowersViewAPI(generics.ListAPIView):
    serializer_class=FollowSerializer
    
    def get_queryset(self):
        return FollowRequest.objects.filter(created_by=self.request.user,status='accepted')
    
class FollowersViewAPI(generics.ListAPIView):
    serializer_class=FollowSerializer
    def get_queryset(self):
        return FollowRequest.objects.filter(receiver=self.request.user,status='accepted')
    
class ReceivedAPIView(generics.ListAPIView):
    serializer_class=FollowSerializer
    def get_queryset(self):
        return FollowRequest.objects.filter(receiver=self.request.user,status='pending')

class SchoolAPIView(generics.ListAPIView):
    serializer_class=SchoolSerializer
    def get_queryset(self):
        return School.objects.filter(is_active=True)

class GradeAPI(generics.ListAPIView):
    serializer_class=GradeSerializer
    queryset=Grade.objects.all()


class StudentProfileView(viewsets.ModelViewSet):
    serializer_class=StudentSerializer
    parser_classes=(FormParser,MultiPartParser)
    http_method_names=['get','patch']

    def get_queryset(self):
        return CustomUser.objects.filter(user_type='STUDENT')
       
