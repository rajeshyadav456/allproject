from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register (School)
admin.site.register(Grade)
admin.site.register(CustomUser)
admin.site.register(PhoneModel)
admin.site.register(Block)
admin.site.register(FollowRequest)

