from django.shortcuts import render
from .models import *
from .serializers import *
from django.shortcuts import render,get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import generics
from .serializers import *
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import  viewsets
from rest_framework.parsers import FormParser,MultiPartParser
# Create your views here.
class PostAPIView(viewsets.ModelViewSet):
    serializer_class=PostSerializer
    queryset=Post.objects.all()
    # permission_classes=(IsCurrentUserOnwerOrReadyOnly,)
    def perform_create(self,serializer):
        serializer.save(created_by=self.request.user,updated_by=self.request.user)

        def user_post(self,request,pk):
            target_user=get_object_or_404(CustomUser,pk=pk)
            data=[]
            if (target_user!=request.user
                and target_user.is_private and not FollowRequest.is_friends(target_user,request.user)):
                return Response({'data':data})
            queryset=self.queryset.filter(created_by=target_user)




class MyLikedPostApiView(generics.ListAPIView):
    serializer_class=PostSerializer
    def get_queryset(self):
        return Post.objects.filter(likes_created_by=self.request.user)
    
class PostItemAPIView(viewsets.ModelViewSet):
    serializer_class=PostItemSerializer
    queryset=PostItem.objects.all()
    http_method_names = ['get', 'post']  # Specify the allowed HTTP methods here

    def perform_create(self,serializer):
        serializer.save(created_by=self.request.user,updated_by=self.request.user)


class LikeAPIView(viewsets.ModelViewSet):
    serializers_class=LikeSerializer
    queryset=Like.objects.all()
    http_method_names = ['post','delete']  # Specify the allowed HTTP methods here

    def create(self,request,*args,**kwargs):
        serializer=self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers=self.get_success_headers(serializer.data)
        response_data=serializer.data
        if not serializer.data['id']:
            response_data={}
        return Response(response_data,status=status.HTTP_201_CREATED,headers=headers)
    def perform_create(self,serializer):
        serializer.save(created_by=self.request.user,updated_by=self.request.user)

    
class CommentAPIView(viewsets.ModelViewSet):
    serializer_class=CommentSerializer
    queryset=Comment.objects.all()
    http_method_names = ['post','delete']  # Specify the allowed HTTP methods here

    def perform_create(self,serializer):
        serializer.save(created_by=self.request.user,updated_by=self.request.user)


class PostCommentAPIView(generics.RetrieveAPIView):
    serializer_class=CommentSerializer
    def get(self,request,post_id):
        comment=Comment.objects.filter(post=post_id)
        serializer=self.serializer_class(comment,context={'request':request},many=True)
        return Response({'data':serializer.data})
    
class MyProfileAPIView(generics.GenericAPIView):
    serializer_class=AllProfileSerializer
    def get(self,request,*args,**kwargs):
        serializer=self.serializer_class(request.user,context={'request':request},many=True)
        return Response({'data':serializer.data})
    
class MypostAPIView(generics.ListAPIView):
    serializer_class=PostSerializer
    def get_queryset(self):
        return Post.objects.filter(created_by=self.request.user.id)
    
class SharePostAPIView(generics.ListAPIView):
    serializer_class=PostSerializer
    def get_queryset(self):
        return Post.objects.filter(created_by=self.request.user)
    
    