from rest_framework import serializers
from .models import *
from app.models import *
from post.models import *
from app.serializers import *
import re

class PohstHashTagSerializer(serializers.ModelSerializer):
    class Meta:
        model=PostHashTag
        fields=('id','hashtag')



class PostItemSerializer(serializers.ModelSerializer):
    class Meta:
        model=PostItem
        fields=('id','post','data','thumbnail','mime_type','created_by','updated_by','created_at','updated_at')
        read_only_fields=('thumbnail','mime_type','created_by','updated_by','created_at','updated_at')

    def create(self,validated_data):
        validated_data['mime_type']=getattr(validated_data.get('data'),'content_type',None)
        data=PostItem.objects.create(**validated_data)
        return data

class PostSerializer(serializers.ModelSerializer):
    items=serializers.SerializerMethodField()
    likes=serializers.SeializerMethodField()
    share=serializers.SeializerMethodField()
    comment=serializers.SeializerMethodField()
    is_like=serializers.SeializerMethodField()
    created_by=CreateSerializer(read_only=True)
    updated_by=CreateSerializer(read_only=True)

    def get_is_likes(self,data_obj):
        return Like.objects.filter(post=data_obj,created_by=self.context['request'].user)
    def get_like(self,data_obj):
        like=data_obj.likes.all().count()
        return like
    def get_share(self,data_obj):
        share=data_obj.post_set.all().cunt
        return share
    def get_comment(self,data_obj):
        comment=data_obj.comments.all().count()
        return comment
    def get_items(self,data_obj):
        items=data_obj.post_items.all()
        return  PostItemSerializer(instance=items,many=True,context=self.context).data
    class Meta:
        models=Post
        fields=('id','caption','description','hashtags','parent','created_by','updated_by','is_like','rating','items','like','share','comment','created_at','updated_at')
        read_only_fields=('created_by','updated_by','created_at','updated_at')
    def create(self,validated_data):
        hashtags=re.findall(r"#\w+",validated_data['caption'])
        post=Post.objects.create(**validated_data)
        tag_ids=[]
        for hashtag in hashtags:
            tag,_=PostHashTag.objects.get_or_create(hashtag=hashtag)
            tag_ids.append(tag.id)
        post.hashtags.add(*tag_ids)
        post.save()
        return post
class LikeSerializer(serializers.ModelSerializer):
    created_by=CreateSerializer(read_only=True)
    updated_by=CreateSerializer(read_only=True)

    class Meta:
        model=Like
        fields=(
            'id',
            'created_by',
            'post',
            'updated_by',
            'created_at',
            'updated_at'
        )
    def create(self,validated_data):
        like=Like.objects.filter(post=validated_data['post'],created_by=self.context['request'].user)
        if like:
            like[0].delete()
            return like[0]
        return super().create(validated_data)
    
class CommentSerializer(serializers.ModelSerializer):
    created_by=CreateSerializer(read_only=True)
    updated_by=CreateSerializer(read_only=True)
    def validate(self,attrs):
        parent_comment=attrs.get('parent_comment')
        if parent_comment and parent_comment.post.id != attrs.get('post').id:
            raise serializers.ValidationError('Invalid Parent Comment Id')
        return super().validate(attrs)
    
    class Meta:
        model=Comment
        fields=('id','parent_comment','post','body','created_by','updated_by','created_at','updated_at')
        read_only_fields=('created_by','updated_by','created_at','updated_at')


class ChildCommentViewSerializer(serializers.ModelSerializer):
    created_by=CreateSerializer(read_only=True)
    updated_by=CreateSerializer(read_only=True)
    class Meta:
        model=Comment
        fields=('id','parent_comment','post','body','created_by','updated_by','created_at','updated_at')
        read_only_fields=('created_by','updated_by','created_at','updated_at')



        