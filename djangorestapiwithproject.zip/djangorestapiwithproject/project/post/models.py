from django.db import models
from utils.models import *
from app.models import *
# Create your models here.
class PostHashTag(models.Model):
    hashtag=models.CharField(max_length=200,null=False)
    def __str__(self):
        return self.hashtag
    
class Post(TimeStampModel):
    caption=models.CharField(max_length=255)
    description=models.TextField()
    hashtag=models.ManyToManyField(PostHashTag,related_query_name='posts')
    parent=models.ForeignKey('self',null=True,blank=True,on_delete=models.CASCADE)
    is_approved=models.BooleanField(default=False)
    is_abused=models.BooleanField(default=False)
    rating=models.IntegerField(blank=True,null=True,default=0)

class PostItem(TimeStampModel):
    post=models.ForeignKey(Post,on_delete=models.CASCADE,related_name='post_items')
    data=models.FileField(upload_to='post_items',blank=True,null=True)
    thumbnail=models.FileField(upload_to='media',blank=True,null=True)
    mime_type=models.CharField(max_length=200,blank=True,null=True)


class Like(TimeStampModel):
    post=models.ForeignKey(Post,on_delete=models.CASCADE,related_name='likes')


class Comment(TimeStampModel):
    post=models.ForeignKey(Post,on_delete=models.CASCADE,related_name='comments')
    parent_comment=models.ForeignKey('self',null=True,blank=True,on_delete=models.CASCADE)
    body=models.TextField()
    is_abused=models.BooleanField(default=False)

class LikeComment(TimeStampModel):
    comment=models.ForeignKey(Comment,on_delete=models.CASCADE,related_name='likecomment')


# class ReportAbuse(TimeStampModel):
#     post=models.ForeignKey(Post,on_delete=models.CASCADE,related_name='posts',blank=True,null=True)
#     comment=models.ForeignKey(Comment,on_delete=models.CASCADE,related_name='comment',blank=True,null=True)
#     user=models.ForeignKey(CustomUser,on_delete=models.CASCADE,related_name='user',blank=True,null=True)
#     reason=models.TextField()




    
