# # Write a program in Python to check given number is prime or not.
# data=int(input('enter a num: '))
# isprime=True
# if data<=1:
#     print('0')
# else:
#     for i in range(2,data):
#         if data%i==0:
#             isprime=False
#             break
# if isprime:
#     print('prime')
# else:
#     print('not prime')


# start=int(input('enter a num: '))
# end=int(input('enter a num: '))
# for num in range(start,end+1):
#     for i in range(2,num):
#         if num%i==0:
#             break
#     else:
#         print(num)

# def data(num):
#     num=int(input('enter a num: '))
#     if num<=0:
#         print('0')
#     else:
#         for i in range(2,num):
#             if num%i==0:
#                 break
#         return num
# d=data(num)
# print(d)


# Write a program in Python to print the Fibonacci series using iterative method.
