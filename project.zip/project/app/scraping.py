# import requests, import BeautifulSoup
# url = 'http://www.google.com/search'
# payload = { 'q' : strToSearch, 'start' : str(start), 'num' : str(num) }
# r = requests.get( url,params = payload, auth=('user', 'pass')) 
# subSoup = BeautifulSoup( subR.text, 'html.parser' )
# text = soup.get_text(separator=' ')   




