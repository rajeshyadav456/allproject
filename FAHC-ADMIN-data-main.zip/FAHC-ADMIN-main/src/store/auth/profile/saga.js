// import { takeEvery, fork, put, all, call } from "redux-saga/effects"

// // Login Redux States
// import { EDIT_PROFILE } from "./actionTypes"
// import { profileSuccess, profileError } from "./actions"



// function* ProfileSaga() {
//   yield all([fork(watchProfile)])
// }

// export default ProfileSaga
