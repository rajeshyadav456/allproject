import React from "react"
import { Redirect } from "react-router-dom"

import Dashboard from "../pages/Dashboard/index"

import PagesMaintenance from "../pages/Utility/pages-maintenance"
// import PagesComingsoon from "../pages/Utility/pages-comingsoon"

import Pages404 from "../pages/Utility/pages-404"
import Pages500 from "../pages/Utility/pages-500"


// Authentication related pages
import Login from "../pages/Authentication/Login"
import Logout from "../pages/Authentication/Logout"

import ForgetPwd from "../pages/Authentication/ForgetPassword"
import ChangePassword from "../pages/Authentication/ChangePassword"

import LockScreen from "../pages/Authentication/LockScreen"

// Profile
import UserProfile from "../pages/Authentication/user-profile"


import Users from "../pages/Users/Users"
import NewUser from "../pages/Users/NewUser"
import EditUser from "../pages/Users/EditUser"
import Contact from '../pages/Contacts/Contact'
import AllChurch from "../pages/ManageChurch/AllChurch"
import ChurchesToCall from "../pages/ManageChurch/ChurchesToCall"
import ClaimedChurches from "../pages/ManageChurch/ClaimedChurches"
import EditAllChurch from "../pages/ManageChurch/EditAllChurch"

import Denomination from "../pages/ManageDenomination/Denomination"


import UpdateDenomination from "../pages/ManageDenomination/UpdateDenomination"
import ManageHouseChurch from '../pages/manageallchurch/ManageHouseChurch'
import EditManageHouseChurch from "../pages/manageallchurch/EditManageHouseChurch"
import EditEvent from '../pages/manageallchurch/EditEvent'
import category from '../pages/category/category'
import EditCategory from "../pages/category/editcategory"
import CreateHouse from "../pages/manageallchurch/CreateHouse" 
import CreateChurch from "../pages/ManageChurch/CreateChurch"
import CreateEvent from "../pages/manageallchurch/CreateEvent"
 

const userRoutes = [
  { path: "/dashboard", component: Dashboard },
  
  { path: "/profile", component: UserProfile },

  
  { path: "/users", component: Users }, 
  { path: "/new-user", component: NewUser }, 
  { path: "/edit-user-profile/:id", component: EditUser }, 

  {path:'/contact', component:Contact},

  {path:'/all-churches', component:AllChurch},
  {path:'/edit-church/:id',component:EditAllChurch},

  {path:'/church-to-calls',component:ChurchesToCall},
  {path:'/create-churches',component:CreateChurch},

  {path:'/claimed-churches',component:ClaimedChurches},

 
  {path:'/house-churches', component:ManageHouseChurch},
  {path:'/edit-house-churches/:id',component:EditManageHouseChurch},
  {path:'/create-house-churches',component:CreateHouse},

  {path:'/edit-event/:id',component:EditEvent},
  {path:'/create-event',component:CreateEvent},

  {path:'/denominations',component:Denomination},
  {path:'/update-denomination/:id',component:UpdateDenomination},
  
  {path:'/categories',component:category},
  {path:'/update-categories/:id',component:EditCategory},
  
  // this route should be at the end of all other routes
  { path: "/", exact: true, component: () => <Redirect to="/dashboard" /> },
]

const authRoutes = [

  { path: "/logout", component: Logout },
  { path: "/login", component: Login },
  { path: "/forgot-password", component: ForgetPwd },
  // { path: "/register", component: Register },
  { path: "/password-reset/:token", component: ChangePassword },
  
  { path: "/pages-maintenance", component: PagesMaintenance },
  // { path: "/pages-comingsoon", component: PagesComingsoon },
  { path: "/pages-404", component: Pages404 },
  { path: "/pages-500", component: Pages500 },

    // // Authentication Inner
    // { path: "/pages-login", component: Login1 },
    // { path: "/pages-register", component: Register1 },
    // { path: "/page-recoverpw", component: Recoverpw },
    { path: "/auth-lock-screen", component: LockScreen },
    //contact

   
    // { path: "/confirm-mail", component: ConfirmMail },
]

export { userRoutes, authRoutes }