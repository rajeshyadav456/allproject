import React, { useState, useEffect } from "react";
import { Row, Col, Card, CardBody, CardTitle, Label, Button, Modal } from "reactstrap"
import { AvForm, AvField } from "availity-reactstrap-validation"
//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"

import { BASE_URL } from "../../helpers/url_helper";
import { get, put } from "../../helpers/api_helper";
import { toast } from 'react-toastify';
import not_avail from "../../assets/images/not_avail.jpg"
import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"
import Select from "react-select";

const optionGroup = [
    {
        label: "Picnic",
        options: [
            { label: "Mustard", value: "Mustard" },
            { label: "Ketchup", value: "Ketchup" },
            { label: "Relish", value: "Relish" },
        ],
    },
    {
        label: "Camping",
        options: [
            { label: "Tent", value: "Tent" },
            { label: "Flashlight", value: "Flashlight" },
            { label: "Toilet Paper", value: "Toilet Paper" },
        ],
    },
];


const EditCustomer = (props) => {
    const state = props.location.statedata
    const { id } = props.match.params
    const [didMount, setDidMount] = useState(false);
    const [user, setUser] = useState(null)
    const [submitting, setSubmitting] = useState(null)
    const [modal_standard, setmodal_standard] = useState(false)
    const [isClaimed, setIsClaimed] = useState(null)
    const [search,setSearch]=useState(null)

    const [name,setName]=useState(null)

    const [ischecked, setIsChecked] = useState(null)
    // const [file, setFile] = useState(null)
    const [img, setImg] = useState(null)
    const [selectedGroup, setselectedGroup] = useState(null);


    function tog_standard() {
        setmodal_standard(!modal_standard)
        removeBodyCss()
    }


    function removeBodyCss() {
        document.body.classList.add("no_padding")
    }

    useEffect(() => {
        loadData(`${BASE_URL}/api/house_church/denominations/?status=true&archive=false`)
        
        setDidMount(true);
        get(`${BASE_URL}/api/house_church/dash_list_churches/${id}/`,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                setUser(response.data)
                // setFile(response.data.image)
                setIsChecked(response.data.status, 'aaaaassssssssssscccccccccc')
                setIsClaimed(response.data.claimed, 'clllllllclllllllllllcclaimed')
                setImg(response.data.image)
                if (response.data.denomination_id){
                    setselectedGroup({label:response.data.denomination_id.name ,value:response.data.denomination_id.id})

                }
            })
        return () => setDidMount(false);

    }, []);

    if (!didMount) {
        return null;
    }
    const handleFileUpload = (e) => {
       
        try {
            let reader = new FileReader();
            let file = e.target.files[0];
            const fileSizeInKB = file.size / 1024;
            if (fileSizeInKB > 30) {
                toast.error('Please select an image file smaller than 30 kB');
                setImg(null)
            }else{
                reader.onloadend = () => {
                    var previewImgUrl = reader.result
                    setImg(previewImgUrl)
                }
                reader.readAsDataURL(file);
            }
        } catch (error) {
        }
    }

    function handleSubmit(e, values) {
        setSubmitting(true)
        put(`${BASE_URL}/api/house_church/dash_list_churches/${id}/`, { ...values, status: ischecked,claimed:isClaimed?1:0 ,search_status:search?1:0, denomination_id:selectedGroup.value},
            { headers: { 'Content-Type': 'application/json', }, validateStatus: false }
        )
            .then(response => {
                if (response.status >= 400) {
                    toast.error("Somthing Went Wrong")
                } else {
                    props.history.push("/all-churches")
                }
            })

    }
  
    function handleImageSubmit(e, values) {
        if (img){
            setSubmitting(true)
            put(`${BASE_URL}/api/house_church/dash_list_churches/${id}/`, { ...values, image: img },
                { headers: { 'Content-Type': 'application/json', }, validateStatus: false }
            )
                .then(response => {
                    if (response.status >= 400) {
                        toast.error("Somthing Went Wrong")
                        setSubmitting(false)
                    } else {
                        props.history.push("/allchurch")
                    }
                })
        }else{
            toast.error('Please select an image file smaller than 30 kB');
        }
        

    }

    function handleSelectGroup(selectedGroup) {
        setselectedGroup(selectedGroup);
    }

    function loadData(url) {
        let data = get(url, { headers: { 'Content-Type': 'application/json', } })
        data.then(response => {
            const formattedOptions = response.data.results.map(items => ({
                value: items.id,
                label: items.name
              }));
        
        
           
            setName(formattedOptions)
            
          
        
        })
      }
    
    function handleDenominationChange(e){
        loadData(`${BASE_URL}/api/house_church/denominations/?status=true&archive=false&name=${e}`)
    }

    return (
        <React.Fragment>
            <div className="page-content">

                <Breadcrumbs title="Churches" breadcrumbItem={user ? user.name : "Church Name"} link="/all-churches" data={state} />
                {user ?
                    <Row>
                        <Col md="12">

                            <Row>
                                <Col sm="4">
                                    <Card>
                                        <CardBody>
                                            <CardTitle></CardTitle>
                                            <Row>
                                                <Col sm="12">

                                                    <div className="text-end">
                                                        <Button color="link" type="button" onClick={() => tog_standard()}>
                                                            <i className="bx bx-edit-alt" style={{ 'fontSize': '30px' }}></i>
                                                        </Button>
                                                    </div>

                                                </Col>
                                                <Col md={12}>
                                                    <div class="text-center">
                                                        <img
                                                            className="img-fluid"
                                                            alt=""
                                                            width="300"
                                                            src={user.image ? user.image : not_avail}
                                                        />

                                                    </div>

                                                </Col>
                                            </Row>

                                        </CardBody>
                                    </Card>

                                </Col>


                                <Col sm="8">
                                    <AvForm className="needs-validation" onValidSubmit={handleSubmit}>
                                        <Card>
                                            <CardBody>
                                                <CardTitle>Church Detail </CardTitle>
                                                <Row>
                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="email">Email</Label>
                                                            <AvField
                                                            name='email'
                                                            placeholder='Email'
                                                            type='email'
                                                            className='form-control'
                                                            id='email'
                                                            value={user.email}/>

                                                        </div>
                                                    </Col>
                                                    <Col md='6'>
                                                        <div className="mb-3">
                                                            <Label htmlFor="pageurl">Page Url</Label>
                                                            <AvField
                                                            name='pageurl'
                                                            placeholder='Page Url'
                                                            type='text'
                                                            className='form-control'
                                                            id='pageurl'
                                                            value={user.pageurl}
                                                            />

                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="name">Name</Label>
                                                            <AvField
                                                                name="name"
                                                                placeholder="Name"
                                                                type="text"
                                                                className="form-control"

                                                                id="name"
                                                                value={user.name}
                                                            />
                                                        </div>

                                                    </Col>
                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="address">Address</Label>
                                                            <AvField
                                                                name="address"
                                                                placeholder="Address"
                                                                type="text"
                                                                errorMessage=" Please Enter Address."
                                                                className="form-control"

                                                                id="address"
                                                                value={user.address}
                                                            />
                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="city">City</Label>
                                                            <AvField
                                                                name="city"
                                                                placeholder="City"
                                                                type="text"
                                                                errorMessage=" Please Enter city."
                                                                className="form-control"

                                                                id="city"
                                                                value={user.city}
                                                            />
                                                        </div>
                                                    </Col>

                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="state">State</Label>
                                                            <AvField
                                                                name="state"
                                                                placeholder="State"
                                                                type="text"
                                                                errorMessage=" Please Enter State."
                                                                className="form-control"

                                                                id="state"
                                                                value={user.state}
                                                            />
                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>


                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="zipcode">ZipCode</Label>
                                                            <AvField
                                                                name="zipcode"
                                                                placeholder="ZipCode"
                                                                type="text"
                                                                errorMessage=" Please provide a valid ZipCode."
                                                                className="form-control"

                                                                id="zipcode"
                                                                value={user.zipcode}
                                                            />
                                                        </div>
                                                    </Col>

                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <AvField
                                                                name="phone"
                                                                label="Phone"
                                                                placeholder="Contact Number"
                                                                type="text"
                                                                errorMessage="Enter Only Digits"
                                                                validate={{
                                                                    pattern: {
                                                                        value: "^[0-9+-]+$",
                                                                        errorMessage: "Invalid Contact"
                                                                    },
                                                                }}
                                                                value={user.phone}
                                                            /> 
                                                        </div>

                                                    </Col>

                                                </Row>
                                                <Row>

                                                    <Col md="6">

                                                        <div className='mb-3'>
                                                            <Label htmlFor="country">Country</Label>
                                                            <AvField
                                                                name='country'
                                                                placeholder='Country'
                                                                type='text'
                                                                className='form-control'
                                                                id='country'
                                                                value={user.country} />



                                                        </div>

                                                    </Col>
                                                    <Col md={6}>
                                                        <div className="mb-3">
                                                            <Label htmlFor="poc">POC</Label>
                                                            <AvField
                                                                name="poc"
                                                                placeholder="Poc"
                                                                type="text"
                                                                errorMessage=" Please provide a valid Poc."
                                                                className="form-control"

                                                                id="poc"
                                                                value={user.poc}
                                                            />
                                                        </div>

                                                    </Col>
                                                </Row>


                                                <Row>
                                                    <Col md="6">
                                                        <div className="mb-3">
                                                            <Label htmlFor="poc_email">POC Email</Label>
                                                            <AvField
                                                                name="poc_email"
                                                                placeholder="Poc Email"
                                                                type="text"
                                                                className="form-control"
                                                                id="poc_email"
                                                                value={user.poc_email}
                                                            />
                                                        </div>

                                                    </Col>
                                                    <Col md="6">
                                                        <div calssName='mb-3'>
                                                            <Label htmlFor='poc_phone'>POC Phone</Label>
                                                            <AvField
                                                                name='poc_phone'
                                                                placeholder='Poc Phone'
                                                                type='text'
                                                                id="poc_phone"
                                                                value={user.poc_phone} />

                                                        </div>

                                                    </Col>
                                                </Row>
                                                <Row>
                                                    <Col md={6}>

                                                        {/* <div className="checkbox-wrapper">
                                                        <label>
                                                            <input type="checkbox"
                                                                checked={ischecked}
                                                                onChange={(e) => setIsChecked(e.target.checked)} />
                                                                Status
                                                        </label>
                                                    </div>  */}
                                                    </Col>
                                                    <Col md={6}>

                                                    </Col>
                                                </Row>

                                                <Row>
                                                <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='e_zip_full'>E Zip Full</Label>
                                                            <AvField
                                                                name='e_zip_full'
                                                                placeholder='E Zip Full'
                                                                type='text'
                                                                className='form-control'
                                                                id="e_zip_full"
                                                                value={user.e_zip_full}
                                                            />

                                                        </div>
                                                    </Col>
                                                    <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label>Denomination</Label>
                                                            <Select
                                                                value={selectedGroup}
                                                                onChange={(e) => {
                                                                    handleSelectGroup(e);
                                                                }}
                                                                onInputChange={(e)=>handleDenominationChange(e)}
                                                                options={name}
                                                                classNamePrefix="select2-selection"
                                                            />

                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                    
                                                <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='loc_county'>LOC Country</Label>
                                                            <AvField
                                                                name='loc_county'
                                                                placeholder='Loc Country'
                                                                type='text'
                                                                className='form-control'
                                                                id='loc_county'
                                                                value={user.loc_county} />
                                                        </div>
                                                    </Col>

                                                    <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='loc_area_code'>LOC Area Code</Label>
                                                            <AvField
                                                                name='loc_area_code'
                                                                placeholder='Loc Area Code'
                                                                type='text'
                                                                className='form-control'
                                                                id='loc_area_code'
                                                                value={user.loc_area_code} />
                                                        </div>
                                                    </Col>
                                                    <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor="loc_fips">LOC Fips</Label>
                                                            <AvField
                                                                name='loc_fips'
                                                                placeholder='Loc Fips'
                                                                type='text'
                                                                className='form-control'
                                                                id='loc_fips'
                                                                value={user.loc_fips} />

                                                        </div>
                                                    </Col>
                                                    <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='loc_msa'>LOC MSA</Label>
                                                            <AvField
                                                                name='loc_msa'
                                                                placeholder='Loc MSA'
                                                                type="text"
                                                                className="form-control"
                                                                id="loc_msa"
                                                                value={user.loc_msa} />

                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                <Col md={6}>
                                                        <div className="mb-3">
                                                            <Label htmlFor="loc_tz">LOC TZ</Label>
                                                            <AvField
                                                                name='loc_tz'
                                                                placeholder='Loc TZ'
                                                                type='text'
                                                                id="loc_tz"
                                                                value={user.loc_tz} />

                                                        </div>
                                                    </Col>
                                                    <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor="loc_lat_poly">LOC Lat Poly</Label>
                                                            <AvField
                                                                name='loc_lat_poly'
                                                                placeholder='Loc Lat Poly'
                                                                type='text'
                                                                id='loc_lat_poly'
                                                                value={user.loc_lat_poly} />
                                                        </div>


                                                    </Col>
                                                </Row>
                                                <Row>

                                                <Col md={6}>
                                                        <div className="mb-3">
                                                            <Label htmlFor='loc_long_poly'>LOC Long Poly</Label>
                                                            <AvField
                                                                name='loc_long_poly'
                                                                placeholder='Loc Long Poly'
                                                                type='text'
                                                                id='loc_long_poly'
                                                                value={user.loc_long_poly} />
                                                        </div>

                                                    </Col>
                                                    <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='lat'>Latitude</Label>
                                                            <AvField
                                                                name='lat'
                                                                placeholder='Lat'
                                                                type='text'
                                                                id='lat'
                                                                value={user.lat} />

                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                <Col md={6}>
                                                        <div className="mb-3">
                                                            <Label htmlFor='lng'>Longitude</Label>
                                                            <AvField
                                                                name='lng'
                                                                placeholder='Lng'
                                                                type='text'
                                                                id='lng'
                                                                value={user.lng} />

                                                        </div>
                                                    </Col>
                                                    <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='loc_dst'>LOC DST</Label>
                                                            <AvField
                                                                name='loc_dst'
                                                                placeholder='Loc DST'
                                                                type='text'
                                                                id='loc_dst'
                                                                value={user.loc_dst} />
                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='website'>Website</Label>
                                                            <AvField
                                                                name='website'
                                                                placeholder='Website'
                                                                type='text'
                                                                id="website"
                                                                value={user.website} />
                                                        </div>
                                                    </Col>
                                                    <Col mb={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='web_meta_title'>Web Meta Title</Label>
                                                            <AvField
                                                                name='web_meta_title'
                                                                placeholder='Web Meta Title'
                                                                type='text'
                                                                id='web_meta_title'
                                                                value={user.web_meta_title} />
                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                <Col mb={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor='web_meta_desc'>Web Meta Desc</Label>
                                                            <AvField
                                                                name='web_meta_desc'
                                                                placeholder='Web Meta Desc'
                                                                type='text'
                                                                id='web_meta_desc'
                                                                value={user.web_meta_desc} />
                                                        </div>
                                                    </Col>
                                                    <Col md={6}>
                                                        <div className="mb-3">
                                                            <Label htmlFor="web_meta_keys">Web Meta Keys</Label>
                                                            <AvField
                                                                name='web_meta_keys'
                                                                placeholder='Web Meta Keys'
                                                                type='text'
                                                                id='web_meta_keys'
                                                                value={user.web_meta_keys} />

                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                <Col md={6}>
                                                        <div className='mb-3'>
                                                            <Label htmlFor="biz_phone_ext">Biz Phone Ext</Label>
                                                            <AvField
                                                                name='biz_phone_ext'
                                                                placeholder='Biz Phone Ext'
                                                                type='text'
                                                                id='biz_phone_ext'
                                                                value={user.biz_phone_ext} />
                                                        </div>
                                                    </Col>
                                                    <Col md={6}>
                                                        <div className="mb-3">
                                                            <Label htmlFor="biz_info">Biz Info</Label>
                                                            <AvField
                                                                name="biz_info"
                                                                placeholder="Biz Info"
                                                                type="textarea"
                                                                className="form-control"
                                                                id="biz_info"
                                                                value={user.biz_info}
                                                            />
                                                        </div>
                                                    </Col>
                                                </Row>


                                                <Row>
                                                    
                                                   
                                                    <Col md={12}>
                                                        <div className="mb-3">
                                                            <Label htmlFor='code'>Code</Label>
                                                            <AvField
                                                                name='code'
                                                                placeholder='Code'
                                                                type='textarea'
                                                                id='code'
                                                                value={user.code} />
                                                        </div>
                                                    </Col>
                                                </Row>

                                                <Row>

                                                    <Col md={4}>
                                                        <div className="checkbox-wrapper mb-2">
                                                            <label>
                                                                <input type="checkbox"
                                                                    checked={ischecked}
                                                                    onChange={(e) => setIsChecked(e.target.checked)} /> {"      "} {"      "}
                                                                Status
                                                            </label>
                                                        </div>
                                                    </Col>
                                                    <Col md={4}>
                                                        <div className="checkbox-wrapper mb-3">
                                                            <label>
                                                                <input type="checkbox"
                                                                    checked={isClaimed}
                                                                    onClick={(e) => setIsClaimed(e.target.checked)}
                                                                /> {"      "} {"      "}
                                                                Claimed
                                                            </label>
                                                        </div>
                                                    </Col>
                                                    <Col md={4}>
                                                    <div className="checkbox-wrapper mb-3">
                                                            <label>
                                                                <input type="checkbox"
                                                                    checked={search}
                                                                    onClick={(e) => setSearch(e.target.checked)}
                                                                /> {"      "} {"      "}
                                                                Search Status
                                                            </label>
                                                        </div>
                                                    </Col>

                                                </Row>
                                            
                                                   
                                                  

                                                {submitting ?
                                                    <button
                                                        type="button"
                                                        className="btn btn-primary waves-effect waves-light my-3"
                                                    >
                                                        <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                        Updating
                                                    </button>
                                                    :
                                                    <Button color="primary" type="submit">
                                                        Update
                                                    </Button>
                                                }
                                            </CardBody>
                                        </Card>
                                    </AvForm>
                                </Col>

                            </Row>


                        </Col>
                        <Row>
                            <Col sm={6} md={4} xl={3}>

                                <Modal
                                    isOpen={modal_standard}
                                    toggle={() => {
                                        tog_standard()
                                    }}
                                >
                                    <div className="modal-header">
                                        <h5 className="modal-title mt-0 " style={{ 'textAlign': 'center' }} id="myModalLabel">
                                            Image
                                        </h5>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setmodal_standard(false)
                                            }}
                                            className="close"
                                            data-dismiss="modal"
                                            aria-label="Close"
                                        >
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="modal-body">
                                        {/* <h5>Overflowing text to show scroll behavior</h5> */}

                                        <Col lg='12'>
                                            <AvForm className="needs-validation" onValidSubmit={handleImageSubmit}>

                                                <Row>
                                                    <Col md={12}>
                                                        <div class="text-center">


                                                        </div>

                                                    </Col>



                                                    {/* <img src={img} alt="Selected" /> */}

                                                    <input type='file' 
                                                     accept="image/png, image/jpeg" className="mb-3 mr-3"   onChange={handleFileUpload} />


                                                </Row>


                                                <div className="modal-footer">
                                                    {submitting ?

                                                        <button
                                                            type="button"
                                                            onClick={() => {
                                                                tog_standard()
                                                            }}
                                                            className="btn btn-primary waves-effect waves-light my-3"
                                                        >
                                                            <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                            Updateimage
                                                        </button>
                                                        :
                                                        <Button color="primary"  type="submit">
                                                            Update
                                                        </Button>
                                                    }
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            tog_standard()
                                                        }}
                                                        className="btn btn-primary waves-effect"
                                                       
                                                        data-dismiss="modal"
                                                    >
                                                        Close
                                                    </button>

                                                </div>


                                            </AvForm>
                                        </Col>


                                    </div>

                                </Modal>
                            </Col>
                        </Row>
                    </Row>

                    :
                    <div id="preloader">
                        <div id="status">
                            <div className="spinner-chase">
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                            </div>
                        </div>
                    </div>
                }

            </div>

        </React.Fragment>
    )
}

export default EditCustomer
