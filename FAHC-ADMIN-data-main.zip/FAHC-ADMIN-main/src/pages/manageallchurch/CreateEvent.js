import React, { useState, useEffect } from "react";
import {
    Row, Col, Card, CardBody, CardTitle, Label, Button, Modal, Dropdown,


} from "reactstrap"

import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';


import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit"

import { toast } from "react-toastify";
import { get, del, post, put, patch } from "../../helpers/api_helper"

import { AvForm, AvField } from "availity-reactstrap-validation"

//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"

import { BASE_URL } from "../../helpers/url_helper";

import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"

import moment from "moment-timezone";
import Select from "react-select";

const optionGroup = [
    {
        label: "Days",
        options: [
            { label: "Monday", value: "Monday" },
            { label: "Tuesday", value: "Tuesday" },
            { label: "Wednesday", value: "Wednesday" },
            { label: 'Thursday', value: 'Thursday' },
            { label: 'Friday', value: 'Friday' },
            { label: 'Saturday', value: 'Saturday' },
            { label: 'Sunday', value: 'Sunday' }
        ],
    },

];
const optionsGroup = [
    {
        label: "Search by",
        options: [
            { label: "Name", value: "name" },
            { label: "Address", value: "address" },
            { label: "Zip Code", value: "zipcode" },
            { label: 'Start Date', value: 'start' },
            { label: 'End Date', value: 'end' }

        ],
    },
];

const EventGroup = [
    {
        label: "Event By",
        options: [
            { label: "once", value: "once" },
            { label: "weekly", value: "weekly" },
            { label: "monthly", value: "monthly" }
        ]
    }
]

const MemberOptionGroup = [
    {
        label: "Search by",
        options: [
            { label: 'Email', value: 'user_email' },
            { label: 'Type', value: 'type' }

        ]
    }
]


const sortOptionGroup = [
    {
        label: "Order by",
        options: [
            { label: "Asc", value: "" },
            { label: "Desc", value: "-" },
        ],
    },
];



const CreateEvent = (props) => {
    const state = props.location.statedata
    const { id } = props.match.params
    const [didMount, setDidMount] = useState(false);
    const [user, setUser] = useState(null)
    const [houseChurch, setHouseChurch] = useState([])
    const [accountUser, setAccountUser] = useState([])
    const [submitting, setSubmitting] = useState(null)
    const [totalSize, settotalSize] = useState(0);
    const [sizePerPage, setsizePerPage] = useState(20)

    const [meberpage, setMemberPage] = useState(1)
    const [membertotalSize, setmembertotalSize] = useState(0);

    const [loaddata, setLoaData] = useState(false)

    const [ids, setIds] = useState([])

    // const [file, setFile] = useState(null)
    const [modal_standard, setmodal_standard] = useState(false)
    const [ischecked, setIsChecked] = useState(null)
    const [isClaimed, setIsClaimed] = useState(null)
    const [isSearch, setIsSearch] = useState(null)

    // const [file, setFile] = useState(null)
    const [img, setImg] = useState(null)
    const [name, setName] = useState([])
    const [day, setDay] = useState([])
    const [church, setChurch] = useState([])
    const [event, setEvent] = useState([])
    const [selectedDenomination, setselectedDenomination] = useState({ label: "Select Denomination", value: null });

    const [activeTab, setactiveTab] = useState("1")
    const [page, setpage] = useState(1)
    const [DisabledPage, setDisabledpage] = useState(1)
    const [filter, setFilter] = useState("")
    const [search, setSearch] = useState("")
    const [search_by, setSearchby] = useState({ label: "Search By", value: null });
    const [order_by, setOrder_by] = useState({ label: "Asc", value: "" });

    const [fromDate, setFromDate] = useState(moment(new Date()).subtract(7, 'd').tz("America/Chicago").format("YYYY-MM-DD"))
    const [toDate, setToDate] = useState(moment(new Date()).tz("America/Chicago").format("YYYY-MM-DD"))
    const [member, setMember] = useState([])


    const [searchBy, setSearchBy] = useState(null);
    const [selectedGroup, setselectedGroup] = useState(null);
    const [selectedHouseGroup, setselectedHouseGroup] = useState({ 'label': 'Select House Church', 'value': null })
    const [selectedUserGroup, setselectedUserGroup] = useState({ 'label': 'Select User', 'value': null })
    const [selectedTypeGroup, setselectedTypeGroup] = useState({ 'label': 'Selecte Type', 'value': null })
    const [selectedDayGroup, setselectedDayGroup] = useState({ "label": "Select Day", "value": null })

    const [houseEvent, setHouseEvent] = useState([])
    const [startDate,setStartDate]=useState([])
    const [endDate,setEndDate]=useState([])






    useEffect(() => {
        loadData(`${BASE_URL}/api/house_church/events/`)
        loadUserData(`${BASE_URL}/api/accounts/users/`)
        loadHouseData(`${BASE_URL}/api/house_church/dash-list-house_church/`)
        loadEventData(`${BASE_URL}/api/house_church/events/`)

        setDidMount(true);
        get(`${BASE_URL}/api/house_church/events/${id}/`,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                console.log(response.data, 'dddddddddddddddddddddddddd')
                setUser(response.data)
                setImg(response.data.image,)
                setStartDate(response.data.start)
                setEndDate(response.data.end)
                





            })



    }, []);




    if (!didMount) {
        return null;
    }

    const handleFileUpload = (e) => {
        try {
            let reader = new FileReader();
            let file = e.target.files[0];
            if (!file) {
                return;
            }
            const fileSizeInKB = file.size / 1024;
            if (fileSizeInKB > 30) {
                toast.error('Please select an image file smaller than 30 kB');
                setImg(null)
            } else {
                reader.onloadend = () => {
                    var previewImgUrl = reader.result
                    setImg(previewImgUrl)
                }
                reader.readAsDataURL(file);
            }

        } catch (error) {

        }
    }

    function handleSubmit(e, values) {
        setSubmitting(true)
        let data = { ...values, image: img, user_id: selectedUserGroup.value, house_id: selectedHouseGroup.value }
        post(`${BASE_URL}/api/house_church/events/`, data,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                if (response.status >= 400) {
                    console.log(response, 'rrrrrr--------------')
                    toast.error("Somthing Went Wrong")
                    setSubmitting(false)
                } else {
                    setSubmitting(false)
                    console.log(response,'rrrrrrrrrrrrrrrrrrrrrrr')
                }
            })

    }



    function loadData(url) {
        let data = get(url, { headers: { 'Content-Type': 'application/json', } })
        data.then(response => {
            const formattedOptions = response.data.results.map(items => ({
                value: items.id,
                label: items.name
            }));
            const formattedDate = new Date(startDate).toLocaleString('en-US', {
                month: '2-digit',
                day: '2-digit',
                year: 'numeric',
        
            });
            setStartDate(formattedDate)
            console.log(formattedDate,'dddddddddddddddddddaaaaaaaaaaaaaaatttttttttttttttttttteeeeeeeeeeeeeeeeeeeee')


            setName(formattedOptions)



        })
    }
    // const formattedDate = new Date(startDate).toLocaleString('en-US', {
    //     month: '2-digit',
    //     day: '2-digit',
    //     year: 'numeric',

    // });

    function loadHouseData(url) {
        let data = get(url, { headers: { 'Content-Type': 'application/json', } })
        data.then(response => {
            const formattedOptions = response.data.results.map((items) => ({
                value: items.id,
                label: items.name
            }));
            setHouseChurch(formattedOptions)
            console.log(formattedOptions, 'hhhhhhhhhhhhhhhhhhhhhhhhcccccccccccccc------------------')
        })

    }
    function loadUserData(url) {
        let data = get(url, { headers: { 'Content-Type': 'application/json', } })
        data.then(response => {
            const formattedOptions = response.data.results.map((items) => ({
                value: items.id,
                label: items.first_name + '' + items.last_name
            }));
            setAccountUser(formattedOptions)
            console.log(formattedOptions, 'usersersersersersersususeuseruser-------------------')
        })
    }
    function loadEventData(url) {
        // let data=get(url,{headers:{'Content-Type':'application/json',}})
        // data.then(response=>{
        //     const formattedOptions=response.data.results.map((items)=>({
        //         value:items.id,
        //         label:items.name
        //     }));
        //     houseEvent(formattedOptions)
        //     console.log(formattedOptions,'tyyyyyyyyytytyytytttttttttyyyyyyyyyyyyyyyyyyyyyppppppppppp')
        // })
    }
    function handleSelectGroup(selectedDenomination) {
        setselectedDenomination(selectedDenomination);
    }
    function handleHouseSelectGroup(selectedHouseGroup) {
        setselectedHouseGroup(selectedHouseGroup);
    }
    function handleUserSelectGroup(selectedUserGroup) {
        setselectedUserGroup(selectedUserGroup);
    }
    function handleTypeSelectGroup(selectedTypeGroup) {
        setselectedTypeGroup(selectedTypeGroup)
    }
    function handleSelectDayGroup(selectedDayGroup) {
        setselectedDayGroup(selectedDayGroup)
    }











    function handleOnSelect(row, isSelect) {
        let id = []
        if (isSelect) {
            id = ids
            id.push(row.id)
        } else {
            for (let i = 0; i < ids.length; i++) {
                if (ids[i] !== row.id) {
                    id.push(ids[i])
                }
            }

        }
        setIds(id)
    }

    function handleOnSelectAll(isSelect, rows) {
        if (isSelect) {
            let email = []
            let id = []
            for (let i = 0; i < rows.length; i++) {
                email.push(rows[i].email.toLowerCase())
                id.push(rows[i].id)
            }
            setIds(id)
        } else {
            setIds([])
        }
    }



    const selectRow = {
        mode: 'checkbox',
        clickToSelect: true,
        onSelect: handleOnSelect,
        onSelectAll: handleOnSelectAll
    };

    function handleSelectGroup(selectedGroup) {
        setselectedGroup(selectedGroup)
    }







    return (
        <React.Fragment>
            <div className="page-content">

                <Breadcrumbs title="House Church" breadcrumbItem="Event Data" link="/house-churches" />

                <Row>
                    <Col lg={12}>



                        {user ?
                            <Row>
                                <Col md="12">

                                    <Row>

                                        <Col sm="10">
                                            <AvForm className="needs-validation" onValidSubmit={handleSubmit}>
                                                <Card>
                                                    <CardBody>
                                                        <CardTitle>Church Detail </CardTitle>
                                                        <Row>
                                                            <Col md="6">
                                                                <div className="mb-3">

                                                                    <Label htmlFor="user_id">User Name</Label>
                                                                    <Select
                                                                        value={selectedUserGroup}
                                                                        onChange={(e) => {
                                                                            handleUserSelectGroup(e);
                                                                        }}
                                                                        options={accountUser}
                                                                        classNamePrefix="select2-selection"
                                                                    />
                                                                </div>
                                                            </Col>

                                                            <Col md="6">
                                                                <div className="mb-3">
                                                                    <Label htmlFor='house_id'>House Name</Label>
                                                                    <Select
                                                                        value={selectedHouseGroup}
                                                                        onChange={(e) => {
                                                                            handleHouseSelectGroup(e);
                                                                        }}
                                                                        options={houseChurch}
                                                                        classNamePrefix="select2-selection"
                                                                    />

                                                                </div>
                                                            </Col>
                                                        </Row>


                                                        <Row>
                                                            <Col md="6">
                                                                <div className="mb-3">
                                                                    <Label htmlFor="name">Name</Label>
                                                                    <AvField
                                                                        name="name"
                                                                        placeholder="Name"
                                                                        type="text"
                                                                        className="form-control"

                                                                        id="name"
                                                                        value={user.name}
                                                                    />
                                                                </div>

                                                            </Col>
                                                            <Col md="6">
                                                                <div className="mb-3">
                                                                    <Label htmlFor="address">Address</Label>
                                                                    <AvField
                                                                        name="address"
                                                                        placeholder="Address"
                                                                        type="text"
                                                                        errorMessage=" Please Enter Address."
                                                                        className="form-control"

                                                                        id="address"
                                                                        value={user.address}
                                                                    />
                                                                </div>
                                                            </Col>
                                                        </Row>
                                                        <Row>
                                                            <Col md="6">
                                                                <div className="mb-3">
                                                                    <Label htmlFor="city">City</Label>
                                                                    <AvField
                                                                        name="city"
                                                                        placeholder="City"
                                                                        type="text"
                                                                        errorMessage=" Please Enter city."
                                                                        className="form-control"

                                                                        id="city"
                                                                        value={user.city}
                                                                    />
                                                                </div>
                                                            </Col>

                                                            <Col md="6">
                                                                <div className="mb-3">
                                                                    <Label htmlFor="state">State</Label>
                                                                    <AvField
                                                                        name="state"
                                                                        placeholder="State"
                                                                        type="text"
                                                                        errorMessage=" Please Enter State."
                                                                        className="form-control"

                                                                        id="state"
                                                                        value={user.state}
                                                                    />
                                                                </div>
                                                            </Col>
                                                        </Row>
                                                        <Row>


                                                            <Col md="6">
                                                                <div className="mb-3">
                                                                    <Label htmlFor="zipcode">ZipCode</Label>
                                                                    <AvField
                                                                        name="zipcode"
                                                                        placeholder="ZipCode"
                                                                        type="text"
                                                                        errorMessage=" Please provide a valid ZipCode."
                                                                        className="form-control"

                                                                        id="zipcode"
                                                                        value={user.zipcode}
                                                                    />
                                                                </div>
                                                            </Col>

                                                            <Col md="6">
                                                                <div className="mb-3">

                                                                    <Label htmlFor='type'>Type</Label>
                                                                    <Select
                                                                        value={selectedTypeGroup}
                                                                        onChange={(e) => {
                                                                            handleTypeSelectGroup(e);
                                                                        }}
                                                                        options={EventGroup}
                                                                        classNamePrefix="select2-selection"
                                                                    />
                                                                </div>
                                                            </Col>



                                                        </Row>
                                                        <Row>

                                                            <Col md="6">
                                                                <div className="mb-3">

                                                                    <Label htmlFor='start'>Start Time</Label>
                                                                    <AvField
                                                                        name='start'
                                                                        placeholder="Start Time"
                                                                        type='date'                                                                        
                                                                        id='start'
                                                                        value={user.start} />
                                                                </div>
                                                            </Col>

                                                            <Col md="6">
                                                                <div className="mb-3">

                                                                    <Label htmlFor='end'>End Time</Label>
                                                                    <AvField
                                                                        name='end'
                                                                        placeholder='End Time'
                                                                        type='date'
                                                                        id='end'
                                                                        value={user.end} />
                                                                </div>

                                                            </Col>

                                                        </Row>


                                                        <Row>
                                                            <Col md='6'>
                                                                <div className="mb-3">

                                                                    <Label htmlFor='monthly_date'>Monthly Date</Label>
                                                                    <AvField
                                                                        name='monthly_date'
                                                                        placeholder='Monthly Date'
                                                                        type='Date'
                                                                        id='monthly_date'
                                                                        value={user.monthly_date} />
                                                                </div>

                                                            </Col>
                                                            <Col md='6'>
                                                                <div className="mb-3">

                                                                    <Label htmlFor="day">Day</Label>
                                                                    <Select
                                                                        value={selectedDayGroup}
                                                                        onChange={(e) => {
                                                                            handleSelectDayGroup(e);
                                                                        }}
                                                                        options={optionGroup}
                                                                        classNamePrefix="select2-selection"
                                                                    />
                                                                </div>

                                                            </Col>
                                                        </Row>
                                                        <Row>
                                                            <Col md='6'>
                                                                <div className="mb-3">
                                                                    <Label htmlFor="time">Time</Label>
                                                                    <AvField
                                                                        name="time"
                                                                        placeholder="Time"
                                                                        type="time"
                                                                        errorMessage=" Please provide a valid TIme."
                                                                        className="form-control"

                                                                        id="time"
                                                                        value={user.time}
                                                                    />
                                                                </div>

                                                            </Col>
                                                            <Col md='6'>
                                                                <div className="mb-3">

                                                                    <Label htmlFor='Desc'>Description</Label>
                                                                    <AvField
                                                                        name='Desc'
                                                                        placeholde='Description'
                                                                        type='textarea'
                                                                        id='Desc'
                                                                        value={user.Desc} />
                                                                </div>
                                                            </Col>

                                                        </Row>
                                                        <Row>
                                                            <Col md={6}>

                                                                <div className="mb-3">
                                                                    <Label>Image</Label>{" "}
                                                                    <input
                                                                        type="file"
                                                                        id="image"
                                                                        accept="image/png, image/jpeg"
                                                                        onChange={(e) => handleFileUpload(e)}
                                                                        value={user.image}
                                                                    />
                                                                </div>

                                                            </Col>
                                                        </Row>






                                                        {submitting ?
                                                            <button
                                                                type="button"
                                                                className="btn btn-primary waves-effect waves-light my-3"
                                                            >
                                                                <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                                Creating
                                                            </button>
                                                            :
                                                            <Button color="primary" type="submit">
                                                                Create
                                                            </Button>
                                                        }
                                                    </CardBody>
                                                </Card>
                                            </AvForm>
                                        </Col>

                                    </Row>


                                </Col>

                            </Row>
                            :
                            <div id="preloader">
                                <div id="status">
                                    <div className="spinner-chase">
                                        <div className="chase-dot"></div>
                                        <div className="chase-dot"></div>
                                        <div className="chase-dot"></div>
                                        <div className="chase-dot"></div>
                                        <div className="chase-dot"></div>
                                        <div className="chase-dot"></div>
                                    </div>
                                </div>
                            </div>
                        }





                    </Col>



                </Row>


            </div>

        </React.Fragment>
    )
}

export default CreateEvent


