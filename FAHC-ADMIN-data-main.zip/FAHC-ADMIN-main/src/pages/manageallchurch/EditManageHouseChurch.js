import React, { useState, useEffect } from "react";
import {
    Row, Col, Card, CardBody, CardTitle, Label, Button, Modal, Dropdown,
    DropdownMenu,
    DropdownItem,
    DropdownToggle,
    TabContent,
    TabPane,
    Collapse,
    NavLink,
    NavItem,
    Nav,
    Spinner

} from "reactstrap"
import classnames from "classnames"
import BootstrapTable from "react-bootstrap-table-next"
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import paginationFactory, {
    PaginationProvider,
    PaginationListStandalone,
    PaginationTotalStandalone,
    SizePerPageDropdownStandalone
} from "react-bootstrap-table2-paginator"

import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit"

import { toast } from "react-toastify";
import { get, del, post, put, patch } from "../../helpers/api_helper"

import { HeaderFormatter } from "../../helpers/methods";
import { AvForm, AvField } from "availity-reactstrap-validation"

//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"

import { BASE_URL } from "../../helpers/url_helper";

import not_avail from "../../assets/images/not_avail.jpg"
import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"

import { Link } from "react-router-dom"
import moment from "moment-timezone";
import Select from "react-select";
import DateRangePicker from 'rsuite/DateRangePicker';

const optionGroup = [
    {
        label: "Days",
        options: [
            { label: "Monday", value: "Monday" },
            { label: "Tuesday", value: "Tuesday" },
            { label: "Wednesday", value: "Wednesday" },
            { label: 'Thursday', value: 'Thursday' },
            { label: 'Friday', value: 'Friday' },
            { label: 'Saturday', value: 'Saturday' },
            { label: 'Sunday', value: 'Sunday' }
        ],
    },

];
const optionsGroup = [
    {
        label: "Search by",
        options: [
            { label: "Name", value: "name" },
            { label: "Address", value: "address" },
            { label: "Zip Code", value: "zipcode" },
            { label: 'Start Date', value: 'start' },
            { label: 'End Date', value: 'end' }

        ],
    },
];

const MemberOptionGroup = [
    {
        label: "Search by",
        options: [
            { label: 'Email', value: 'user_email' },
            { label: 'Type', value: 'type' }

        ]
    }
]


const sortOptionGroup = [
    {
        label: "Order by",
        options: [
            { label: "Asc", value: "" },
            { label: "Desc", value: "-" },
        ],
    },
];



const EditCustomer = (props) => {
    const state = props.location.statedata
    const { id } = props.match.params
    const [didMount, setDidMount] = useState(false);
    const [user, setUser] = useState(null)
    const [submitting, setSubmitting] = useState(null)
    const [totalSize, settotalSize] = useState(0);
    const [sizePerPage, setsizePerPage] = useState(20)

    const [meberpage, setMemberPage] = useState(1)
    const [membertotalSize, setmembertotalSize] = useState(0);

    const [loaddata, setLoaData] = useState(false)

    const [ids, setIds] = useState([])

    // const [file, setFile] = useState(null)
    const [modal_standard, setmodal_standard] = useState(false)
    const [ischecked, setIsChecked] = useState(null)
    // const [file, setFile] = useState(null)
    const [img, setImg] = useState(null)
    const [name, setName] = useState([])
    const [day, setDay] = useState([])
    const [church, setChurch] = useState([])
    const [event, setEvent] = useState([])
    const [selectedDenomination, setselectedDenomination] = useState({ label: "Select Denomination", value: null });
    const [SelectedDay, setSelectedDay] = useState({ label: " Select days", value: null });
    const [SelectedChurch, setSelectedChurch] = useState({ label: 'select church', value: null });

    const [activeTab, setactiveTab] = useState("1")
    const [page, setpage] = useState(1)
    const [DisabledPage, setDisabledpage] = useState(1)
    const [filter, setFilter] = useState("")
    const [search, setSearch] = useState("")
    const [search_by, setSearchby] = useState({ label: "Search By", value: null });
    const [order_by, setOrder_by] = useState({ label: "Asc", value: "" });

    const [fromDate, setFromDate] = useState(moment(new Date()).subtract(7, 'd').tz("America/Chicago").format("YYYY-MM-DD"))
    const [toDate, setToDate] = useState(moment(new Date()).tz("America/Chicago").format("YYYY-MM-DD"))
    const [member, setMember] = useState([])

    const [selectedDate, setSelectedDate] = useState(null);
    const [searchBy, setSearchBy] = useState(null);
    const [startDate, setStartDate] = useState([])
    const [endDate, setEndDate] = useState([])


    const handleSearchByChange = (selectedOption) => {
        setSearchBy(selectedOption);

        // Clear the selected date when a different option is selected
        setSelectedDate(null);
    };

    const handleDateChange = (date) => {
        setSelectedDate(date);

        // Do something with the selected date
    };

    function toggle(tab) {
        if (activeTab !== tab) {
            setactiveTab(tab)
        }
    }




    function tog_standard() {
        setmodal_standard(!modal_standard)
        removeBodyCss()
    }


    function removeBodyCss() {
        document.body.classList.add("no_padding")
    }

    const columns = [
        {
            dataField: "id",
            text: "S No.",
            hidden: true

        },

        {
            dataField: "name",
            text: "Name",
            sort: true,
            headerFormatter: HeaderFormatter,
            formatter: (cellContent, row) => (

                <Link to={{ pathname: `/edit-event/${row.id}`, statedata: { 'activeTab': activeTab, 'page': { "2": page, '3': DisabledPage } } }} className="me-3 text-dark">{cellContent}</Link>
            ),
            title: (cell) => `${cell}`
        },

        {
            dataField: "address",
            text: "Address",
            headerFormatter: HeaderFormatter,
            sort: true,
            formatter: (cellContent, row) => (
                <Link to={{ pathname: `/edit-event/${row.id}`, statedata: { 'activeTab': activeTab, 'page': { "2": page, '3': DisabledPage } } }} className="me-3 text-dark">{cellContent}</Link>
            ),
        },
        {


            dataField: "city",
            text: "City",
            sort: true,
            headerFormatter: HeaderFormatter,
            formatter: (cellContent, row) => (
                <Link to={{ pathname: `/edit-event/${row.id}`, statedata: { 'activeTab': activeTab, 'page': { "2": page, '3': DisabledPage } } }} className="me-3 text-dark">{cellContent}</Link>

            )

        },
        {


            dataField: "zipcode",
            text: "Zip Code",
            sort: true,
            headerFormatter: HeaderFormatter,
            formatter: (cellContent, row) => (
                <Link to={{ pathname: `/edit-event/${row.id}`, statedata: { 'activeTab': activeTab, 'page': { "2": page, '3': DisabledPage } } }} className="me-3 text-dark">{cellContent}</Link>

            )

        },
        {


            dataField: "start",
            text: "Start Date",
            sort: true,
            headerFormatter: HeaderFormatter,
            formatter: (cellContent, row) => (
                <Link to={{ pathname: `/edit-event/${row.id}`, statedata: { 'activeTab': activeTab, 'page': { "2": page, '3': DisabledPage } } }} className="me-3 text-dark">{moment(new Date(row.start)).subtract(7, 'd').tz("America/Chicago").format("MM-DD-YYYY")}</Link>

            )

        },

        {


            dataField: "end",
            text: "End Date",
            sort: true,
            headerFormatter: HeaderFormatter,
            formatter: (cellContent, row) => (
                <Link to={{ pathname: `/edit-event/${row.id}`, statedata: { 'activeTab': activeTab, 'page': { "2": page, '3': DisabledPage } } }} className="me-3 text-dark">{moment(new Date(row.end)).subtract(7, 'd').tz("America/Chicago").format("MM-DD-YYYY")}</Link>

            )

        },

        {
            dataField: "action",
            isDummyField: true,
            headerFormatter: HeaderFormatter,
            text: "Action",
            formatter: (cellContent, row) => (
                <React.Fragment>
                    <Link to={{ pathname: `/edit-event/${row.id}`, }} className="me-3 text-primary"><i className="mdi mdi-pencil font-size-18"></i>{cellContent}</Link>

                </React.Fragment>

            ),
        },
    ]
    const Data = [
        {
            dataField: "id",
            text: "S No.",
            hidden: true

        },
        {
            dataField: "type",
            text: "Type",
            sort: true,
            headerFormatter: HeaderFormatter,
            formatter: (cellContent, row) => (

                <Link to="#" className="me-3 text-dark">{cellContent}</Link>
            )

        },


        {
            dataField: "user_email",
            text: "Email",
            sort: true,
            headerFormatter: HeaderFormatter,
            formatter: (cellContent, row) => (

                <Link to={{ pathname: `/edit-churches/${row.id}`, statedata: { 'activeTab': activeTab, 'page': { "2": page, '3': DisabledPage } } }} className="me-3 text-dark">{cellContent}</Link>
            )

        },



    ]
    useEffect(() => {
        loadData(`${BASE_URL}/api/house_church/denominations/?status=true&archive=false`)
        loadChurchData(`${BASE_URL}/api/house_church/dash_list_churches/?status=true&archive=false`)
        loaddData(`${BASE_URL}/api/house_church/events/?house_id=${id}`, 20, 1)
        loadMember(`${BASE_URL}/api/house_church/dash-house-members/?house_id=${id}`, 20, 1)

        setDidMount(true);
        get(`${BASE_URL}/api/house_church/dash-list-house_church/${id}/`,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                setUser(response.data)
                console.log(response.data.image)
                setImg(response.data.image)

                setIsChecked(response.data.status)
                console.log(response.data.church_id.name, 'nnnnnnnnnnnnnnnnn')
                console.log(response.data.denomination_id.name, 'nnnnnnnnnnnnnnndddddddddddddddddddddddddd')

                if (response.data.denomination_id) {
                    setselectedDenomination({ label: response.data.denomination_id.name, value: response.data.denomination_id.id })

                }
                if (response.data.church_id) {
                    setSelectedChurch({ label: response.data.church_id.name, value: response.data.church_id.id })
                }
                if (response.data.days) {
                    setSelectedDay({ label: response.data.days, value: response.data.days })
                }
            })
        // return () => setDidMount(false);

    }, []);

    function loaddData(url, sizePerPage, page) {
        let data = get(url, { headers: { 'Content-Type': 'application/json', } })
        data.then(response => {
            console.log(response, 'newwennnnnnnnnnnnnnwenwennwenwenwenenwnewnwenwennewn')
            setEvent(response.data.results)
            setStartDate(moment(new Date()).subtract(7, 'd').tz("America/Chicago").format("MM-DD-YYYY"))
            console.log(moment(new Date()).subtract(7, 'd').tz("America/Chicago").format("MM-DD-YYYY"), 'dddddddddddddddddddaaaaaaaaaaaaaaatttttttttttttttttttteeeeeeeeeeeeeeeeeeeee')

     
            settotalSize(response.data.count)
            console.log(response.data.count, 'countcountcoutncoutn')
            console.log(response.data, 'sssssssssssssssssssss')
            setpage(page)
            setsizePerPage(sizePerPage)
            setLoaData(true)



        })
    }

    function loadMember(url, sizePerPage, page) {
        let data = get(url, { headers: { 'Content-Type': 'application/json', } })
        data.then(response => {
            console.log(response.data)
            setMember(response.data.results)
            setmembertotalSize(response.data.count)
            setsizePerPage(sizePerPage)
            setMemberPage(page)
            setLoaData(true)


        })

    }


    if (!didMount) {
        return null;
    }

    const handleFileUpload = (e) => {

        try {
            let reader = new FileReader();
            let file = e.target.files[0];
            const fileSizeInKB = file.size / 1024;
            if (fileSizeInKB > 30) {
                toast.error('Please select an image file smaller than 30 kB');
                setImg(null)
            } else {
                reader.onloadend = () => {
                    var previewImgUrl = reader.result
                    setImg(previewImgUrl)
                    console.log(previewImgUrl)
                }
                reader.readAsDataURL(file);
            }
        } catch (error) {
        }
    }
    function handleSubmit(e, values) {
        setSubmitting(true)
        console.log(selectedDenomination, 'ggggggggggg')
        let data = {
            ...values, status: ischecked, denomination_id: selectedDenomination.value, church_id: SelectedChurch.value
            , days: SelectedDay.value, user_id: user.user_id.id
        }
        put(`${BASE_URL}/api/house_church/dash-list-house_church/${id}/`, data,
            { headers: { 'Content-Type': 'application/json', }, validateStatus: false }
        )
            .then(response => {
                if (response.status >= 400) {
                    console.log(response)
                    toast.error("Somthing Went Wrong")
                } else {
                    props.history.push("/house-churches")
                }
            })

    }

    function handleImageSubmit(e, values) {
        console.log(img, 'iiiiiiiiiiiiiiiii')
        if (img) {
            setSubmitting(true)
            put(`${BASE_URL}/api/house_church/dash_list_churches/${id}/`, { ...values, image: img },
                { headers: { 'Content-Type': 'application/json', }, validateStatus: false }
            )
                .then(response => {
                    if (response.status >= 400) {
                        console.log(response)
                        toast.error("Somthing Went Wrong")
                        setSubmitting(false)
                    } else {
                        props.history.push("/house-churches")
                    }
                })
        } else {
            toast.error('Please select an image file smaller than 30 kB');
        }


    }
    function loadData(url) {
        let data = get(url, { headers: { 'Content-Type': 'application/json', } })
        data.then(response => {
            console.log(response.data.results)
            const formattedOptions = response.data.results.map(items => ({
                value: items.id,
                label: items.name
            }));
           
          


        setName(formattedOptions)



    })
}
function loadChurchData(url) {
    let data = get(url, { headers: { 'Content-Type': 'application/json', } })
    data.then(response => {
        const formattedOptions = response.data.results.map(items => ({
            value: items.id,
            label: items.name
        }));
        console.log(formattedOptions, 'ddaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadddddddd')
        setChurch(formattedOptions)

    })
}


function handleSelectGroup(selectedDenomination) {
    setselectedDenomination(selectedDenomination);
}

function handleSelectDayGroup(SelectedDay) {
    setSelectedDay(SelectedDay)
}
function handleSelectChurchGroup(SelectedChurch) {
    setSelectedChurch(SelectedChurch)

}
function handleChurchInputChange(e) {
    loadChurchData(`${BASE_URL}/api/house_church/dash_list_churches/?status=true&archive=false&name=${e}`)
}
function handleDenominationChange(e) {
    loadData(`${BASE_URL}/api/house_church/denominations/?status=true&archive=false&name=${e}`)
}

function ClearFilter() {

    setFilter("")
    setSearch("")
    setSearchby({ label: "Search By", value: null });
    setFromDate(moment(new Date()).subtract(7, 'd').tz("America/Chicago").format("YYYY-MM-DD"))
    setToDate(moment(new Date()).tz("America/Chicago").format("YYYY-MM-DD"))

    loaddData(`${BASE_URL}/api/house_church/events/`, 20, 1)


}



function FilterData(e, values) {
    let filter_data = ""
    if (!search_by.value) {
        toast.error("Select Search Field")
    } else {
        if (search_by.value === "start") {
            filter_data = `start_from=${fromDate}&start_to=${toDate}`
        } else if (search_by.value === 'end') {
            filter_data = `end_from=${fromDate}&end_to=${toDate}`
        } else {
            filter_data = `${search_by.value}=${values.search}`

        }
        filter_data = filter_data + `&order_by=${order_by.value}${search_by.value}`
        console.log(filter_data, 'fdfdfdfdddffddfdfdfdfdfdfdf')
        loaddData(`${BASE_URL}/api/house_church/events/?${filter_data}`, 20, 1)
        loadMember(`${BASE_URL}/api/house_church/house-members/?${filter_data}`, 20, 1)


        setFilter(filter_data)


    }
}


function NoDataIndication() {
    if (loaddata && church.length === 0) {
        return (

            <div className="d-flex align-items-center justify-content-center">
                <h4 className="my-3">Table is Empty</h4>
            </div>
        )

    } else {
        return (

            <div className="d-flex align-items-center justify-content-center">
                <Spinner className="my-3" color="dark" />
            </div>
        )

    }
}
function MemberNoDataIndication() {
    if (loaddata && event.length === 0) {
        return (
            <div className="d-flex align-items-center justify-content-center">
                <h4 className="my-3">Table is Empty</h4>
            </div>
        )
    }
}
function EventNoDataIndication() {
    if (loadMember && member.length === 0) {
        return (
            <div className="d-flex align-items-center justify-content-center">
                <h4 className="my-3">Table is Empty</h4>
            </div>
        )
    }
}
function handleTableChange(type, { page, sizePerPage, searchText, }) {

    setTimeout(() => {
        setLoaData(false)
        setEvent([])
        let new_page = page
        let url = `${BASE_URL}/api/house_church/events/?page_size=${sizePerPage}&page=${new_page}`
        console.log(url, 'uuuuuu')
        // if (filter !== ""){
        //   url = `${url}${filter}`
        // }
        window.scrollTo(0, 0)
        loaddData(url, sizePerPage, new_page, searchText)


    }, 1000);
}

function handleMemberTableChange(type, { page, sizePerPage, searchText, }) {
    setTimeout(() => {
        setLoaData(false)
        setMember([])
        let new_page = page
        let url = `${BASE_URL}/api/house_church/events/?page_size=${sizePerPage}&page=${new_page}`
        console.log(url, 'uuuuuu')
        window.scrollTo(0, 0)
        loadMember(url, sizePerPage, new_page, searchText)
    }, 100);

}
function handleOnSelect(row, isSelect) {
    let id = []
    if (isSelect) {
        id = ids
        id.push(row.id)
    } else {
        for (let i = 0; i < ids.length; i++) {
            if (ids[i] !== row.id) {
                id.push(ids[i])
            }
        }

    }
    setIds(id)
}

function handleOnSelectAll(isSelect, rows) {
    if (isSelect) {
        let email = []
        let id = []
        for (let i = 0; i < rows.length; i++) {
            email.push(rows[i].email.toLowerCase())
            id.push(rows[i].id)
        }
        setIds(id)
    } else {
        setIds([])
    }
}



const selectRow = {
    mode: 'checkbox',
    clickToSelect: true,
    onSelect: handleOnSelect,
    onSelectAll: handleOnSelectAll
};




const defaultSorted = [{
    dataField: 'f_name',
    order: 'desc',
    savestate: true
}];


//pagination customization
const pageOptions = {
    page: page,
    sizePerPage: sizePerPage,
    totalSize: totalSize, // replace later with size(Order),
    custom: true,
    sizePerPageList: [{
        text: '20', value: 20
    }, {
        text: '50', value: 50
    }, {
        text: '100', value: 100
    }, {
        text: '200', value: 200
    }]

}
const MemberPageOptions = {
    page: meberpage,
    sizePerPage: sizePerPage,
    totalSize: membertotalSize,
    custom: true,
    sizePerPageList: [{
        text: '20', value: 20
    }, {
        text: '50', value: 50
    },
    {
        text: '100', value: 100
    },
    {
        text: '200', value: 200
    }]

}
function dateFormatter(start) {
    const date = new Date(start);
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const year = date.getFullYear();

    const formattedDate = `${month}/${day}/${year}`;

    return formattedDate;
}



return (
    <React.Fragment>
        <div className="page-content">

            <Breadcrumbs title="House Church" breadcrumbItem={user ? user.name : "Edit House Church"} link="/house-churches" data={state} />

            <Row>
                <Col lg={12}>
                    <Card>
                        <CardBody>
                            {/* <CardTitle className="h4">Default Tabs</CardTitle>
                <p className="card-title-desc">Use the tab JavaScript plugin—include it individually or through the compiled <code className="highlighter-rouge">bootstrap.js</code> file—to extend our navigational tabs and pills to create tabbable panes of local content, even via dropdown menus.</p>
 */}

                            <Nav tabs>
                                <NavItem>
                                    <NavLink
                                        style={{ cursor: "pointer" }}
                                        className={classnames({
                                            active: activeTab === "1",
                                        })}
                                        onClick={() => {
                                            toggle("1")
                                        }}
                                    >
                                        <span className="d-block d-sm-none"><i className="fas fa-home"></i></span>
                                        <span className="d-none d-sm-block">Detail                                                                           </span>
                                    </NavLink>
                                </NavItem>
                                <NavItem>
                                    <NavLink
                                        style={{ cursor: "pointer" }}
                                        className={classnames({
                                            active: activeTab === "2",
                                        })}
                                        onClick={() => {
                                            toggle("2")
                                        }}
                                    >
                                        <span className="d-block d-sm-none"><i className="far fa-user"></i></span>
                                        <span className="d-none d-sm-block">Event</span>
                                    </NavLink>
                                </NavItem>
                                <NavItem>
                                    <NavLink
                                        style={{ cursor: "pointer" }}
                                        className={classnames({
                                            active: activeTab === "3",
                                        })}
                                        onClick={() => {
                                            toggle("3")
                                        }}
                                    >
                                        <span className="d-block d-sm-none"><i className="far fa-envelope"></i></span>
                                        <span className="d-none d-sm-block">Member</span>
                                    </NavLink>
                                </NavItem>

                            </Nav>

                            <TabContent activeTab={activeTab} className="p-3 text-muted">
                                <TabPane tabId="1">
                                    {user ?
                                        <Row>
                                            <Col md="12">

                                                <Row>
                                                    <Col sm="4">
                                                        <Card>
                                                            <CardBody>
                                                                <CardTitle></CardTitle>
                                                                <Row>
                                                                    <Col sm="12">
                                                                        <div className="text-end">
                                                                            <Button color='link' type='button' onClick={() => tog_standard()} >
                                                                                <i className="bx bx-edit-alt" style={{ 'fontSize': '30px' }}></i>

                                                                            </Button>
                                                                        </div>
                                                                    </Col>

                                                                    <Col md={12}>
                                                                        <div className="text-center">
                                                                            <img
                                                                                className="img-fluid"
                                                                                alt=""
                                                                                width="300"
                                                                                src={user.image ? user.image : not_avail}
                                                                            />

                                                                        </div>
                                                                        {/* <input type='file' onChange={handleFileUpload}/> */}
                                                                        {/* <img src={img} alt='Selected'/> */}
                                                                    </Col>


                                                                </Row>

                                                            </CardBody>
                                                        </Card>

                                                    </Col>
                                                    <Col sm="8">
                                                        <AvForm className="needs-validation" onValidSubmit={handleSubmit}>
                                                            <Card>
                                                                <CardBody>
                                                                    <CardTitle>House Church </CardTitle>
                                                                    <Row>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="name">Name</Label>
                                                                                <AvField
                                                                                    name="name"
                                                                                    placeholder="Name"
                                                                                    type="text"
                                                                                    className="form-control"

                                                                                    id="name"
                                                                                    value={user.name}
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="address">Address</Label>
                                                                                <AvField
                                                                                    name="address"
                                                                                    placeholder="Address"
                                                                                    type="text"
                                                                                    errorMessage=" Please Enter Address."
                                                                                    className="form-control"

                                                                                    id="address"
                                                                                    value={user.address}
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                    </Row>
                                                                    <Row>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="city">City</Label>
                                                                                <AvField
                                                                                    name="city"
                                                                                    placeholder="City"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid City."
                                                                                    className="form-control"

                                                                                    id="city"
                                                                                    value={user.city}
                                                                                />
                                                                            </div>


                                                                        </Col>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="state">State</Label>
                                                                                <AvField
                                                                                    name="state"
                                                                                    placeholder="State"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid State."
                                                                                    className="form-control"

                                                                                    id="state"
                                                                                    value={user.state}
                                                                                />
                                                                            </div>

                                                                        </Col>
                                                                    </Row>

                                                                    <Row>
                                                                        <Col md="6">
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="zipcode">Zip Code</Label>
                                                                                <AvField
                                                                                    name="zipcode"
                                                                                    placeholder="ZipCode"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid ZipCode."
                                                                                    className="form-control"

                                                                                    id="zipcode"
                                                                                    value={user.zipcode}
                                                                                />
                                                                            </div>
                                                                        </Col>

                                                                        <Col md="6">
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="user_id">User</Label>
                                                                                <AvField
                                                                                    name="user_id"
                                                                                    placeholder="User"
                                                                                    type="text"
                                                                                    errorMessage="Please provide a valid User."
                                                                                    className="form-control"
                                                                                    disabled

                                                                                    id="user_id"
                                                                                    value={user.user_id.first_name}
                                                                                />
                                                                            </div>

                                                                        </Col>
                                                                    </Row>
                                                                    <Row>
                                                                        <Col sm={6}>

                                                                            <div className="mb-3">
                                                                                <Label htmlFor="church">Church</Label>
                                                                                <Select
                                                                                    value={SelectedChurch}
                                                                                    onChange={(e) => {
                                                                                        handleSelectChurchGroup(e);
                                                                                    }}
                                                                                    onInputChange={(e) => handleChurchInputChange(e)}
                                                                                    options={church}
                                                                                    classNamePrefix="select2-selection"
                                                                                />
                                                                            </div>
                                                                        </Col>

                                                                        <Col sm={6}>

                                                                            <div className="mb-3">
                                                                                <Label htmlFor="name">Denomination</Label>
                                                                                <Select
                                                                                    value={selectedDenomination}
                                                                                    onChange={(e) => {
                                                                                        handleSelectGroup(e);
                                                                                    }}
                                                                                    onInputChange={(e) => handleDenominationChange(e)}
                                                                                    options={name}
                                                                                    classNamePrefix="select2-selection"
                                                                                />
                                                                            </div>

                                                                        </Col>

                                                                    </Row>

                                                                    <Row>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="days">Days</Label>
                                                                                <Select
                                                                                    value={SelectedDay}
                                                                                    onChange={(e) => {
                                                                                        handleSelectDayGroup(e);
                                                                                    }}
                                                                                    options={optionGroup}
                                                                                    classNamePrefix="select2-selection"
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="time">Time</Label>
                                                                                <AvField
                                                                                    name="time"
                                                                                    placeholder="Time"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid TIme."
                                                                                    className="form-control"

                                                                                    id="time"
                                                                                    value={user.time}
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                    </Row>
                                                                    <Row>
                                                                        <Col md={6}>
                                                                            {/* <div className="mb-3">
                                                            <Label htmlFor="gallery">Gallery</Label>
                                                            <AvField
                                                                name="gallery"
                                                                placeholder="Gallery"
                                                                type="text"
                                                                errorMessage=" Please provide a valid Gallery."
                                                                className="form-control"

                                                                id="gallery"
                                                                value={user.gallery}
                                                            />
                                                        </div> */}
                                                                        </Col>
                                                                        <Col md={6}>

                                                                        </Col>
                                                                    </Row>
                                                                    <Row>

                                                                    </Row>
                                                                    <Row>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="special_inst">Special Inst</Label>
                                                                                <AvField
                                                                                    name="special_inst"
                                                                                    placeholder="Special Inst"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid Special Inst."
                                                                                    className="form-control"

                                                                                    id="special_inst"
                                                                                    value={user.special_inst}
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="type">Type</Label>
                                                                                <AvField
                                                                                    name="type"
                                                                                    placeholder="Type"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid Videos."
                                                                                    className="form-control"

                                                                                    id="type"
                                                                                    value={user.type}
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                    </Row>
                                                                    <Row>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="latitude">Latitude</Label>
                                                                                <AvField
                                                                                    name="latitude"
                                                                                    placeholder="Latitude"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid Latitude."
                                                                                    className="form-control"

                                                                                    id="latitude"
                                                                                    value={user.latitude}
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                        <Col md={6}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="longitude">Longitude</Label>
                                                                                <AvField
                                                                                    name="longitude"
                                                                                    placeholder="longitude"
                                                                                    type="text"
                                                                                    errorMessage=" Please provide a valid longitude."
                                                                                    className="form-control"

                                                                                    id="longitude"
                                                                                    value={user.longitude}
                                                                                />
                                                                            </div>
                                                                        </Col>
                                                                    </Row>
                                                                    <Row>
                                                                        <Col md={12}>
                                                                            <div className="mb-3">
                                                                                <Label htmlFor="info">Info</Label>
                                                                                <AvField
                                                                                    name="info"
                                                                                    placeholder="Info"
                                                                                    type="textarea"
                                                                                    errorMessage=" Please provide a valid Info."
                                                                                    className="form-control"

                                                                                    id="info"
                                                                                    value={user.info}
                                                                                />
                                                                            </div>
                                                                        </Col>

                                                                    </Row>
                                                                    <Row>

                                                                        <Col md={6}>
                                                                            <div className="checkbox-wrapper">
                                                                                <label>
                                                                                    <input type="checkbox"
                                                                                        checked={ischecked}
                                                                                        onChange={(e) => setIsChecked(e.target.checked)} />{" "}
                                                                                    Status
                                                                                </label>
                                                                            </div>
                                                                        </Col>
                                                                    </Row>


                                                                    {submitting ?
                                                                        <button
                                                                            type="button"
                                                                            className="btn btn-primary waves-effect waves-light my-3"
                                                                        >
                                                                            <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                                            Updating
                                                                        </button>
                                                                        :
                                                                        <Button color="primary" type="submit">
                                                                            Update
                                                                        </Button>
                                                                    }
                                                                </CardBody>
                                                            </Card>
                                                        </AvForm>
                                                    </Col>

                                                </Row>


                                            </Col>
                                            <Row>
                                                <Col sm={6} md={4} xl={3}>

                                                    <Modal
                                                        isOpen={modal_standard}
                                                        toggle={() => {
                                                            tog_standard()
                                                        }}
                                                    >
                                                        <div className="modal-header">
                                                            <h5 className="modal-title mt-0 " style={{ 'textAlign': 'center' }} id="myModalLabel">
                                                                Image
                                                            </h5>
                                                            <button
                                                                type="button"
                                                                onClick={() => {
                                                                    setmodal_standard(false)
                                                                }}
                                                                className="close"
                                                                data-dismiss="modal"
                                                                aria-label="Close"
                                                            >
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div className="modal-body">
                                                            {/* <h5>Overflowing text to show scroll behavior</h5> */}

                                                            <Col lg='12'>
                                                                <AvForm className="needs-validation" onValidSubmit={handleImageSubmit}>

                                                                    <Row>
                                                                        <Col md={12}>
                                                                            <div class="text-center">


                                                                            </div>

                                                                        </Col>



                                                                        {/* <img src={img} alt="Selected" /> */}

                                                                        <input type='file' accept="image/png, image/jpeg" className="mb-3 mr-3" onChange={handleFileUpload} />


                                                                    </Row>


                                                                    <div className="modal-footer">
                                                                        {submitting ?

                                                                            <button
                                                                                type="button"
                                                                                onClick={() => {
                                                                                    tog_standard()
                                                                                }}
                                                                                className="btn btn-primary waves-effect waves-light my-3"
                                                                            >
                                                                                <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                                                Updateimage
                                                                            </button>
                                                                            :
                                                                            <Button color="primary" type="submit">
                                                                                Update
                                                                            </Button>
                                                                        }
                                                                        <button
                                                                            type="button"
                                                                            onClick={() => {
                                                                                tog_standard()
                                                                            }}
                                                                            className="btn btn-primary waves-effect"

                                                                            data-dismiss="modal"
                                                                        >
                                                                            Close
                                                                        </button>

                                                                    </div>


                                                                </AvForm>
                                                            </Col>


                                                        </div>

                                                    </Modal>
                                                </Col>
                                            </Row>
                                        </Row>
                                        :
                                        <div id="preloader">
                                            <div id="status">
                                                <div className="spinner-chase">
                                                    <div className="chase-dot"></div>
                                                    <div className="chase-dot"></div>
                                                    <div className="chase-dot"></div>
                                                    <div className="chase-dot"></div>
                                                    <div className="chase-dot"></div>
                                                    <div className="chase-dot"></div>
                                                </div>
                                            </div>
                                        </div>
                                    }



                                </TabPane>
                                <TabPane tabId="2" className="p-3">

                                    <PaginationProvider
                                        pagination={paginationFactory(pageOptions)}
                                        data={event}
                                    >
                                        {({ paginationProps, paginationTableProps }) => (
                                            <ToolkitProvider
                                                keyField="id"
                                                data={event}
                                                columns={columns}
                                                remote={{ filter: true, pagination: true, sort: true, cellEdit: true }}
                                                bootstrap5
                                                search
                                            >
                                                {toolkitProps => (
                                                    <React.Fragment>
                                                        <AvForm className="needs-validation" onValidSubmit={FilterData}>
                                                            <Row className="mb-2">


                                                                <Col sm="3">
                                                                    <div className="text-sm-start mb-2">
                                                                        <Select
                                                                            value={search_by}
                                                                            onChange={(e) => {
                                                                                setSearchby(e)
                                                                            }}
                                                                            options={optionsGroup}
                                                                            classNamePrefix="select2-selection"
                                                                        />
                                                                    </div>


                                                                </Col>
                                                                <Col sm='7'>
                                                                </Col>
                                                                <Col sm='2'>
                                                                <div className="flex end">
                                                                <a href='/create-event'>
                                                                        <Button type='button' color='primary'><i className='bx bx-plus'></i>{" "}
                                                                            Create Events</Button>

                                                                    </a>
                                                                </div>
                                                                </Col>
                                                                {search_by.value ?
                                                                    <Col sm="9">
                                                                        <Row>
                                                                            <Col sm="5">
                                                                                {search_by.value === "start" || search_by.value === "end" ?
                                                                                    <Row>
                                                                                        <Col sm="6">
                                                                                            <div className="text-sm-end mb-2">


                                                                                                <AvField
                                                                                                    name="from_date"
                                                                                                    placeholder="Received From"
                                                                                                    type="date"
                                                                                                    errorMessage="From Date"
                                                                                                    className="form-control"
                                                                                                    value={fromDate}
                                                                                                    onChange={(e) => setFromDate(e.target.value)}
                                                                                                    id="from_date"
                                                                                                />
                                                                                            </div>

                                                                                        </Col>
                                                                                        <Col sm="6">
                                                                                            <div className="text-sm-end mb-2">
                                                                                                <AvField
                                                                                                    name="to_date"
                                                                                                    placeholder="Category"
                                                                                                    type="date"
                                                                                                    errorMessage="To Date"
                                                                                                    className="form-control"

                                                                                                    value={toDate}
                                                                                                    onChange={(e) => setToDate(e.target.value)}
                                                                                                    id="to_date"
                                                                                                />
                                                                                            </div>
                                                                                        </Col>
                                                                                    </Row>
                                                                                    : search_by.value !== null ?
                                                                                        <Row>
                                                                                            <Col sm="12">
                                                                                                <div className="text-sm-end mb-2">
                                                                                                    <AvField
                                                                                                        name="search"
                                                                                                        placeholder={search_by.label}
                                                                                                        type="text"
                                                                                                        value={search}
                                                                                                        onChange={(e) => setSearch(e.target.value)}
                                                                                                        className="form-control"
                                                                                                        validate={{ required: { value: true } }}
                                                                                                    />
                                                                                                </div>

                                                                                            </Col>

                                                                                        </Row>

                                                                                        : null}

                                                                            </Col>
                                                                            <Col sm="3">
                                                                                <div className="text-sm-start mb-2">
                                                                                    <Select
                                                                                        value={order_by}
                                                                                        onChange={(e) => {
                                                                                            setOrder_by(e)
                                                                                        }}
                                                                                        options={sortOptionGroup}
                                                                                        classNamePrefix="select2-selection"
                                                                                    />
                                                                                </div>
                                                                            </Col>
                                                                            <Col sm="4">
                                                                                <Button type="submit" color="success" className="btn-rounded me-2" >
                                                                                    Filter
                                                                                </Button>
                                                                                {" "}
                                                                                <Button type="button" color="primary" onClick={() => ClearFilter()} className="btn-rounded" >
                                                                                    Clear
                                                                                </Button>
                                                                            </Col>
                                                                        </Row>
                                                                    </Col>
                                                                    : null}



                                                            </Row >
                                                        </AvForm>



                                                        <div className="table-responsive">

                                                            <BootstrapTable
                                                                remote
                                                                {...toolkitProps.baseProps}
                                                                {...paginationTableProps}
                                                                responsive
                                                                bordered={false}
                                                                striped={true}
                                                                dataFormat={dateFormatter}
                                                                defaultSorted={defaultSorted}

                                                                hover
                                                                classes={
                                                                    "table align-middle table-nowrap table-check"
                                                                }
                                                                headerWrapperClasses={"table-light"}
                                                                onTableChange={handleTableChange}
                                                                noDataIndication={() => MemberNoDataIndication()}
                                                                selectRow={selectRow}
                                                            />

                                                        </div>
                                                        <Row>
                                                            <Col sm={6}>
                                                                <div className="mb-3">
                                                                    <SizePerPageDropdownStandalone
                                                                        {...paginationProps}
                                                                    />
                                                                </div>
                                                                <div className="pagination pagination-rounded mb-2">
                                                                    <PaginationTotalStandalone
                                                                        {...paginationProps}
                                                                    />
                                                                </div>

                                                            </Col>
                                                            <Col sm={6}>
                                                                <div className="pagination pagination-rounded justify-content-end mb-2">
                                                                    <PaginationListStandalone
                                                                        {...paginationProps}
                                                                    />
                                                                </div>

                                                            </Col>
                                                        </Row>


                                                    </React.Fragment>
                                                )}
                                            </ToolkitProvider>
                                        )}
                                    </PaginationProvider>
                                </TabPane>
                                <TabPane tabId="3" className="p-3">

                                    <PaginationProvider
                                        pagination={paginationFactory(MemberPageOptions)}
                                        data={member}
                                    >
                                        {({ paginationProps, paginationTableProps }) => (
                                            <ToolkitProvider
                                                keyField="id"
                                                data={member}
                                                columns={Data}
                                                remote={{ filter: true, pagination: true, sort: true, cellEdit: true }}
                                                bootstrap5
                                                search
                                            >
                                                {toolkitProps => (
                                                    <React.Fragment>
                                                        <AvForm className="needs-validation" onValidSubmit={FilterData}>
                                                            <Row className="mb-2">

                                                                <Col sm="3">
                                                                    <div className="text-sm-start mb-2">
                                                                        <Select
                                                                            value={search_by}
                                                                            onChange={(e) => {
                                                                                setSearchby(e)
                                                                            }}
                                                                            options={MemberOptionGroup}
                                                                            classNamePrefix="select2-selection"
                                                                        />
                                                                    </div>


                                                                </Col>
                                                                {search_by.value ?
                                                                    <Col sm="9">
                                                                        <Row>
                                                                            <Col sm="5">
                                                                                {search_by.value !== null ?
                                                                                    <Row>
                                                                                        <Col sm="12">
                                                                                            <div className="text-sm-end mb-2">
                                                                                                <AvField
                                                                                                    name="search"
                                                                                                    placeholder={search_by.label}
                                                                                                    type="text"
                                                                                                    value={search}
                                                                                                    onChange={(e) => setSearch(e.target.value)}
                                                                                                    className="form-control"
                                                                                                    validate={{ required: { value: true } }}
                                                                                                />
                                                                                            </div>

                                                                                        </Col>

                                                                                    </Row>

                                                                                    : null}

                                                                            </Col>
                                                                            <Col sm="3">
                                                                                <div className="text-sm-start mb-2">
                                                                                    <Select
                                                                                        value={order_by}
                                                                                        onChange={(e) => {
                                                                                            setOrder_by(e)
                                                                                        }}
                                                                                        options={sortOptionGroup}
                                                                                        classNamePrefix="select2-selection"
                                                                                    />
                                                                                </div>
                                                                            </Col>
                                                                            <Col sm="4">
                                                                                <Button type="submit" color="success" className="btn-rounded me-2" >
                                                                                    Filter
                                                                                </Button>
                                                                                {" "}
                                                                                <Button type="button" color="primary" onClick={() => ClearFilter()} className="btn-rounded" >
                                                                                    Clear
                                                                                </Button>
                                                                            </Col>
                                                                        </Row>
                                                                    </Col>
                                                                    : null}



                                                            </Row >
                                                        </AvForm>



                                                        <div className="table-responsive">

                                                            <BootstrapTable
                                                                remote
                                                                {...toolkitProps.baseProps}
                                                                {...paginationTableProps}
                                                                responsive
                                                                bordered={false}
                                                                striped={true}
                                                                defaultSorted={defaultSorted}
                                                                hover
                                                                classes={
                                                                    "table align-middle table-nowrap table-check"
                                                                }
                                                                headerWrapperClasses={"table-light"}
                                                                onTableChange={handleMemberTableChange}
                                                                noDataIndication={() => EventNoDataIndication()}
                                                            // selectRow={selectRow}
                                                            />

                                                        </div>
                                                        <Row>
                                                            <Col sm={6}>
                                                                <div className="mb-3">
                                                                    <SizePerPageDropdownStandalone
                                                                        {...paginationProps}
                                                                    />
                                                                </div>
                                                                <div className="pagination pagination-rounded mb-2">
                                                                    <PaginationTotalStandalone
                                                                        {...paginationProps}
                                                                    />
                                                                </div>

                                                            </Col>
                                                            <Col sm={6}>
                                                                <div className="pagination pagination-rounded justify-content-end mb-2">
                                                                    <PaginationListStandalone
                                                                        {...paginationProps}
                                                                    />
                                                                </div>

                                                            </Col>
                                                        </Row>


                                                    </React.Fragment>
                                                )}
                                            </ToolkitProvider>
                                        )}
                                    </PaginationProvider>
                                </TabPane>
                            </TabContent>
                        </CardBody>
                    </Card>
                </Col>



            </Row>


        </div>

    </React.Fragment>
)
}

export default EditCustomer
