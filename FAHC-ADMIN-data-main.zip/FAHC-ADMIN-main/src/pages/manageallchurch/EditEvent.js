import React, { useState, useEffect } from "react";
import { Row, Col, Card, CardBody, CardTitle, Label, Button, Modal } from "reactstrap"
import { AvForm, AvField } from "availity-reactstrap-validation"
//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"

import { BASE_URL } from "../../helpers/url_helper";
import { get, put } from "../../helpers/api_helper";
import { toast } from 'react-toastify';
import not_avail from "../../assets/images/not_avail.jpg"
import { getAccessToken } from "../../helpers/jwt-token-access/accessToken"
import Select from "react-select";

const optionGroup = [
    {
        label: "Picnic",
        options: [
            { label: "Mustard", value: "Mustard" },
            { label: "Ketchup", value: "Ketchup" },
            { label: "Relish", value: "Relish" },
        ],
    },
    {
        label: "Camping",
        options: [
            { label: "Tent", value: "Tent" },
            { label: "Flashlight", value: "Flashlight" },
            { label: "Toilet Paper", value: "Toilet Paper" },
        ],
    },
];


const EditCustomer = (props) => {
    const state = props.location.statedata
    const { id } = props.match.params
    const [didMount, setDidMount] = useState(false);
    const [user, setUser] = useState(null)
    const [submitting, setSubmitting] = useState(null)
    const [modal_standard, setmodal_standard] = useState(false)
    const [search, setSearch] = useState(null)

    const [name, setName] = useState(null)

    // const [file, setFile] = useState(null)
    const [img, setImg] = useState(null)


    function tog_standard() {
        setmodal_standard(!modal_standard)
        removeBodyCss()
    }


    function removeBodyCss() {
        document.body.classList.add("no_padding")
    }

    useEffect(() => {
        // loadData(`${BASE_URL}/api/house_church/denominations/?status=true&archive=false`)

        setDidMount(true);
        get(`${BASE_URL}/api/house_church/events/${id}/`,
            { headers: { 'Content-Type': 'application/json', 'Authorization': getAccessToken() }, validateStatus: false }
        )
            .then(response => {
                setUser(response.data)
                // setFile(response.data.image)
                console.log(response.data, 'eeevvvvvvvvvvvvvvvvvvveeeeeeeeeennnnnnnnnnnttttttttt')

                setImg(response.data.image)
                console.log(response.data.image, 'iiiiiiiiiiii')


            })
        return () => setDidMount(false);

    }, []);

    if (!didMount) {
        return null;
    }
    const handleFileUpload = (e) => {
        
        try {
            let reader = new FileReader();
            let file = e.target.files[0];
            if (!file){
                return;
            }
            const fileSizeInKB=file.size/1024;
            if (fileSizeInKB>30){
                toast.error('Please select an image file smaller than 30 kB');
                return;
            }
            reader.onloadend = () => {
                var previewImgUrl = reader.result
                setImg(previewImgUrl)
                console.log(previewImgUrl)
            }
            reader.readAsDataURL(file);
        } catch (error) {
        }
    }

    function handleSubmit(e, values) {
        
        setSubmitting(true)
        put(`${BASE_URL}/api/house_church/events/${id}/`, { ...values ,user_id:user.user_id.id},
            { headers: { 'Content-Type': 'application/json', }, validateStatus: false }
        )
            .then(response => {
                if (response.status >= 400) {
                    console.log(response)
                    toast.error("Somthing Went Wrong")
                } else {
                    props.history.push(`/edit-event/${id}`)
                    
                }
            })

    }

    function handleImageSubmit(e, values) {
        setSubmitting(true)
        put(`${BASE_URL}/api/house_church/events/${id}/`, { ...values, image: img },
            { headers: { 'Content-Type': 'application/json', }, validateStatus: false }
        )
            .then(response => {
                if (response.status >= 400) {
                    console.log(response)
                    toast.error("Somthing Went Wrong")
                } else {
                    props.history.push(`/edit-event/${id}`)
                }
            })

    }






    return (
        <React.Fragment>
            <div className="page-content">

                <Breadcrumbs title="Churches" breadcrumbItem={user ? user.name : "Church Name"} link="/all-churches" data={state} />
                {user ?
                    <Row>
                        <Col md="12">

                            <Row>
                                <Col sm="4">
                                    <Card>
                                        <CardBody>
                                            <CardTitle></CardTitle>
                                            <Row>
                                                <Col sm="12">

                                                    <div className="text-end">
                                                        <Button color="link" type="button" onClick={() => tog_standard()}>
                                                            <i className="bx bx-edit-alt" style={{ 'fontSize': '30px' }}></i>
                                                        </Button>
                                                    </div>

                                                </Col>
                                                <Col md={12}>
                                                    <div className="text-center">
                                                        <img
                                                            className="img-fluid"
                                                            disabled
                                                            alt=""
                                                            width="300"
                                                            // src={user.image?user.image:not_avail}
                                                            src={user.image ? user.image : not_avail}
                                                        />

                                                    </div>

                                                </Col>
                                            </Row>

                                        </CardBody>
                                    </Card>

                                </Col>


                                <Col sm="8">
                                    <AvForm className="needs-validation" onValidSubmit={handleSubmit}>
                                        <Card>
                                            <CardBody>
                                                <CardTitle>Church Detail </CardTitle>
                                                <Row>
                                               
                                                    <Col md='6'>
                                                        <div className="mb-3">
                                                            <Label htmlFor="user_id">User</Label>
                                                            <AvField
                                                                name="user_id"
                                                                placeholder="User"
                                                                type="text"
                                                                errorMessage="Please provide a valid User."
                                                                className="form-control"
                                                                disabled

                                                                id="user_id"
                                                                value={user.user_id.first_name}
                                                            />
                                                        </div>

                                                    </Col>
                                                    <Col md='6'>
                                                    <div className="mb-3">
                                                            <Label htmlFor="name">Name</Label>
                                                            <AvField
                                                                name="name"
                                                                placeholder="Name"
                                                                type="text"
                                                                className="form-control"
                                                                disabled

                                                                id="name"
                                                                value={user.name}
                                                            />
                                                        </div>

                                                    </Col>
                                                </Row>

                                                <Row>
                                                    <Col md="6">
                                                    <div className="mb-3">
                                                            <Label htmlFor="address">Address</Label>
                                                            <AvField
                                                                name="address"
                                                                placeholder="Address"
                                                                type="text"
                                                                errorMessage=" Please Enter Address."
                                                                className="form-control"
                                                                disabled
                                                                id="address"
                                                                value={user.address}
                                                            />
                                                        </div>

                                                    </Col>
                                                    <Col md="6">
                                                    <div className="mb-3">
                                                            <Label htmlFor="city">City</Label>
                                                            <AvField
                                                                name="city"
                                                                placeholder="City"
                                                                type="text"
                                                                errorMessage=" Please Enter city."
                                                                className="form-control"
                                                                disabled
                                                                id="city"
                                                                value={user.city}
                                                            />
                                                        </div>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                    <Col md="6">
                                                    <div className="mb-3">
                                                            <Label htmlFor="state">State</Label>
                                                            <AvField
                                                                name="state"
                                                                placeholder="State"
                                                                type="text"
                                                                errorMessage=" Please Enter State."
                                                                className="form-control"
                                                                disabled
                                                                id="state"
                                                                value={user.state}
                                                            />
                                                        </div>
                                                    </Col>

                                                    <Col md="6">
                                                    <div className="mb-3">
                                                            <Label htmlFor="zipcode">ZipCode</Label>
                                                            <AvField
                                                                name="zipcode"
                                                                placeholder="ZipCode"
                                                                type="text"
                                                                errorMessage=" Please provide a valid ZipCode."
                                                                className="form-control"
                                                                disabled
                                                                id="zipcode"
                                                                value={user.zipcode}
                                                            />
                                                        </div>
                                                    </Col>
                                                </Row>
                                             
                                                <Row>
                                                    <Col md='6'>
                                                        <div className='mb-3'>
                                                            <Label htmlFor="time">Time</Label>
                                                            <AvField
                                                                name='time'
                                                                placeholder='Time'
                                                                type='time'
                                                                className='form-control'
                                                                disabled
                                                                id='desc'
                                                                value={user.time} />



                                                        </div>

                                                    </Col>
                                                    <Col md='6'>
                                                    <div className='mb-3'>
                                                            <Label htmlFor="day">Day</Label>
                                                            <AvField
                                                                name='day'
                                                                placeholder='Day'
                                                                type='text'
                                                                className='form-control'
                                                                disabled
                                                                id='day'
                                                                value={user.day} />



                                                        </div>
                                                    </Col>
                                                    
                                                </Row>
                                                <Row>
                                                    <Col md='12'>
                                                    <div className='mb-3'>
                                                            <Label htmlFor="desc">Description</Label>
                                                            <AvField
                                                                name='desc'
                                                                placeholder='Desc'
                                                                type='textarea'
                                                                className='form-control'
                                                                disabled
                                                                id='desc'
                                                                value={user.desc} />



                                                        </div>
                                                    </Col>
                                                </Row>










                                                {submitting ?
                                                    <button
                                                        type="button"
                                                        className="btn btn-primary waves-effect waves-light my-3"
                                                    >
                                                        <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                        Updating
                                                    </button>
                                                    :
                                                    <Button color="primary" type="submit">
                                                        Update
                                                    </Button>
                                                }
                                            </CardBody>
                                        </Card>
                                    </AvForm>
                                </Col>

                            </Row>


                        </Col>
                        <Row>
                            <Col sm={6} md={4} xl={3}>

                                <Modal
                                    isOpen={modal_standard}
                                    toggle={() => {
                                        tog_standard()
                                    }}
                                >
                                    <div className="modal-header">
                                        <h5 className="modal-title mt-0 " style={{ 'textAlign': 'center' }} id="myModalLabel">
                                            Image
                                        </h5>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setmodal_standard(false)
                                            }}
                                            className="close"
                                            data-dismiss="modal"
                                            aria-label="Close"
                                        >
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="modal-body">
                                        {/* <h5>Overflowing text to show scroll behavior</h5> */}

                                        <Col lg='12'>
                                            <AvForm className="needs-validation" onValidSubmit={handleImageSubmit}>

                                                <Row>
                                                    <Col md={12}>
                                                        <div class="text-center">


                                                        </div>

                                                    </Col>



                                                    {/* <img src={img} alt="Selected" /> */}

                                                    <input type='file' accept="image/png, image/jpeg" className="mr-5 mb-3 text-center" onChange={handleFileUpload} />


                                                </Row>


                                                <div className="modal-footer">
                                                    {submitting ?

                                                        <button
                                                            type="button"
                                                            onClick={() => {
                                                                tog_standard()
                                                            }}
                                                            className="btn btn-primary waves-effect waves-light my-3"
                                                        >
                                                            <i className="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>{" "}
                                                            Updateimage
                                                        </button>
                                                        :
                                                        <Button color="primary" type="submit">
                                                            Update
                                                        </Button>
                                                    }
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            tog_standard()
                                                        }}
                                                        className="btn btn-primary waves-effect"
                                                       
                                                        data-dismiss="modal"
                                                    >
                                                        Close
                                                    </button>

                                                </div>


                                            </AvForm>
                                        </Col>


                                    </div>

                                </Modal>
                            </Col>
                        </Row>
                    </Row>

                    :
                    <div id="preloader">
                        <div id="status">
                            <div className="spinner-chase">
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                                <div className="chase-dot"></div>
                            </div>
                        </div>
                    </div>
                }

            </div>

        </React.Fragment>
    )
}

export default EditCustomer
