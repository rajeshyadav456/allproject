import PropTypes from 'prop-types'
import React, { useEffect, useState } from "react"

import { Row, Col, Alert, Container } from "reactstrap"

// Redux
import { connect } from "react-redux"
import { withRouter, Link } from "react-router-dom"

// availity-reactstrap-validation
import { AvForm, AvField } from "availity-reactstrap-validation"

// actions
import { loginUser, apiError, socialLogin } from "../../store/actions"

import { BASE_URL, SITE_URL } from '../../helpers/url_helper'

// import images
import logo from "../../assets/images/logo-sm.png"

const Login = (props) => {
  const [error, setErrors] = useState("")
  useEffect(() => {
    document.body.className = "authentication-bg";
    // remove classname when component will unmount
    return function cleanup() {
      document.body.className = "";
    };
  });


  const handleSubmit = (event, values)=> {

    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
    };   
    try{
        fetch(`${BASE_URL}/api/accounts/login/`,requestOptions)
        .then(res => 
            {if(res.status >= 400){
                res.json()
                .then(
                    (data) =>{ setErrors(data.detail) }
                )
            }
            else{
                res.json()
                .then(
                    (data) =>{
                      // console.log(data,'dddddddddddddddddddddddddddddddddddd')
                    localStorage.setItem("authUser", JSON.stringify(data));
                    props.history.push('/dashboard');
                    }
                )
            }    
        }
    )
    }catch(error){
        console.log(error)
        setErrors("somthing Went Wrong");
    }
}

  return (
    <React.Fragment>
      <div className="account-pages my-5 pt-sm-5">
        <Container>
          <Row className="justify-content-center">
            <Col md={8} lg={6} xl={5}>
              <div className="card overflow-hidden">
                <div className="bg-login text-center">
                  <div className="bg-login-overlay"></div>
                  <div className="position-relative">
                    <h5 className="text-white font-size-20">Welcome Back !</h5>
                    <p className="text-white-50 mb-0">Sign in to continue to FAHC.</p>
                    <Link to="/" className="logo logo-admin mt-4">
                      <img src={logo} alt="" height="60" />
                    </Link>
                  </div>
                </div>
                <div className="card-body pt-5">
                  <div className="p-2">
                    <AvForm
                      className="form-horizontal"
                      onValidSubmit={(e, v) => {
                        handleSubmit(e, v)
                      }}
                    >
                      {error !== "" ? (
                        <Alert color="danger">{error}</Alert>
                      ) : null}
                      <div className="mb-3">
                        <AvField
                          name="email"
                          label="Email"
                          className="form-control"
                          placeholder="Enter Email"
                          type="email"
                          required
                        />
                      </div>

                      <div className="mb-3">
                        <AvField
                          name="password"
                          label="Password"
                          value="123456"
                          type="password"
                          required
                          placeholder="Enter Password"
                        />
                      </div>

                      <div className="mt-3">
                        <button
                          className="btn btn-dark w-100 waves-effect waves-light"
                          type="submit"
                        >
                          Log In
                        </button>
                      </div>

                      <div className="mt-4 text-center">
                        <Link to="/forgot-password" className="text-muted"><i
                          className="mdi mdi-lock me-1"></i> Forgot your password?</Link>
                      </div>
                    </AvForm>

                  </div>
                </div>
              </div>
              <div className="mt-5 text-center">
                
              <p>© {'2023'} <a target="_blank" rel="noreferrer" className="text-warning" href={SITE_URL}>{'findahousechurch.com'}</a> </p>
              </div>
            </Col>
          </Row>

        </Container>
      </div>
    </React.Fragment>
  )
}

const mapStateToProps = state => {
  const { error } = state.Login
  return { error }
}

export default withRouter(
  connect(mapStateToProps, { loginUser, apiError, socialLogin })(Login)
)

Login.propTypes = {
  error: PropTypes.any,
  history: PropTypes.object,
  loginUser: PropTypes.func,
  socialLogin: PropTypes.func
}